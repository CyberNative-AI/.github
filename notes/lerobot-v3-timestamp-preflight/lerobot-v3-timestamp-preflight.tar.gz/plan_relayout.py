"""Plan a file-and-time relayout for a LeRobot v3 camera whose episodes point at the wrong video file.

LeRobot 0.4.0-0.4.2 merges (#2550) can leave an episode pointing at the file the merge reached at the end of
its source (bug 1) and later episodes carrying a running offset (bug 2). Merges copy source videos in episode
order, so the frames themselves are packed in episode_index order across the camera's files. This planner
rebuilds that packed layout from order and sample counts alone and proposes the stored values that LeRobot
0.7.0 would have written for the same frames.

Input per camera: its MP4 files in (chunk, file) order, each with sample times and durations; the episodes in
episode_index order with length, stored file and stored from/to; each episode's tabular timestamps.
Refused unless: every file is on the regular 1/fps grid; episodes fill the files in order, each episode inside
one file and every file used to its last sample; every row query from the new start lands on its own
sample; and every change is one the known faults make:
- file: stored files never go back to an earlier file in episode order, each stored file is the packed file or
  a later one, and an episode that names a later file is followed by the first episode packed in that file
  naming it too (its source continued into that file);
- time: the stored duration equals the episode's length, and the stored start is the packed start plus an
  offset that is zero on the first episode packed in each file and, once it starts, the same to the end of
  that file. A nonzero offset must equal either the duration of all earlier files of the camera (what the
  LeRobot 0.4.0-0.4.2 merge adds) or the duration of the episodes at the end of the previous file that name
  a later file (the shape found on a public archive with both faults). Any other offset is refused.
Edits name old and new values for file, from_timestamp and to_timestamp. No I/O here.
"""

from plan_rollover import TOL, Refused, near


def offset_evidence(files, packed, stored, lengths, key, fps):
    """The offsets the known faults can carry into packed file `key`: name -> seconds."""
    keys = [k for k, _, _ in files]
    i = keys.index(key)
    if i == 0:
        return {}
    evidence = {"earlier files": sum(len(points) for _, points, _ in files[:i]) / fps}
    previous, tail = keys[i - 1], 0
    for m in range(packed.index(key) - 1, -1, -1):
        if packed[m] != previous or stored[m] <= previous:
            break
        tail += lengths[m]
    if tail:
        evidence["misfiled episodes at the end of the previous file"] = tail / fps
    return evidence


def camera_relayout(camera, files, episodes, timestamps, fps):
    """files: list of (key, points, durations), key = (chunk, file), in key order.
    episodes: list of dicts with episode_index, length, file (key), from, to, in episode_index order."""
    if not files:
        raise Refused(f"{camera}: no video files")
    keys = [key for key, _, _ in files]
    if keys != sorted(keys) or len(set(keys)) != len(keys):
        raise Refused(f"{camera}: video files out of order or repeated")
    for key, points, durations in files:
        if not points or len(points) != len(durations):
            raise Refused(f"{camera}: empty or inconsistent video index for file {list(key)}")
        if not all(near(p, i / fps) for i, p in enumerate(points)) or not all(near(d, 1 / fps) for d in durations):
            raise Refused(f"{camera}: file {list(key)} is not on the regular 1/fps grid")
    numbers = [e["episode_index"] for e in episodes]
    if numbers != list(range(len(numbers))):
        raise Refused(f"{camera}: episode indices are not 0..n-1 in order")
    current, position, placed = 0, 0, []
    for e in episodes:
        length = e["length"]
        if type(length) is not int or length <= 0:
            raise Refused(f"{camera}, episode {e['episode_index']}: invalid length")
        if position == len(files[current][1]):
            if current + 1 == len(files):
                raise Refused(f"{camera}: more episode frames than video samples")
            current, position = current + 1, 0
        key, points, _ = files[current]
        if position + length > len(points):
            raise Refused(f"{camera}, episode {e['episode_index']}: would cross the end of file {list(key)}")
        placed.append((e, key, position))
        position += length
    if current != len(files) - 1 or position != len(files[current][1]):
        raise Refused(f"{camera}: episode frames do not use every video sample exactly once")
    stored = [tuple(e["file"]) for e in episodes]
    if stored != sorted(stored):
        raise Refused(f"{camera}: stored files go back to an earlier file in episode order, which the known "
                      "merge faults do not produce")
    packed = [key for _, key, _ in placed]
    lengths = [e["length"] for e in episodes]
    points_by_key = {key: points for key, points, _ in files}
    carried, edits = {}, []
    for n, (e, key, start) in enumerate(placed):
        label = f"{camera}, episode {e['episode_index']}"
        points = points_by_key[key]
        new_from = points[start]
        new_to = new_from + e["length"] / fps
        times = timestamps[e["episode_index"]]
        if len(times) != e["length"]:
            raise Refused(f"{label}: tabular rows differ from length")
        if not all(near(new_from + t, points[start + k]) for k, t in enumerate(times)):
            raise Refused(f"{label}: row queries miss their samples")
        # #2550 can only point an episode at a later file (bug 1) and only add an offset (bug 2)
        if stored[n] < key or e["from"] < new_from - TOL:
            raise Refused(f"{label}: stored file or start is earlier than the packed one, which the known merge "
                          "faults do not produce")
        if stored[n] > key and (stored[n] not in packed or stored[packed.index(stored[n])] != stored[n]):
            raise Refused(f"{label}: names file {list(stored[n])}, but the first episode in that file does not, "
                          "so no source continued into it")
        offset = e["from"] - new_from
        if near(offset, 0):
            if key in carried:
                raise Refused(f"{label}: the offset carried by earlier episodes in file {list(key)} stops here, "
                              "which the known merge faults do not produce")
        elif key in carried:
            if not near(offset, carried[key]):
                raise Refused(f"{label}: offset {offset:.6f} s differs from the {carried[key]:.6f} s carried by "
                              f"earlier episodes in file {list(key)}")
        else:
            if n == 0 or packed[n - 1] != key:
                raise Refused(f"{label}: the first episode in file {list(key)} is offset by {offset:.6f} s; the "
                              "known merge faults start each file without an offset")
            evidence = offset_evidence(files, packed, stored, lengths, key, fps)
            if not any(near(offset, value) for value in evidence.values()):
                known = ", ".join(f"{name} {value:.6f} s" for name, value in evidence.items()) or "none"
                raise Refused(f"{label}: offset {offset:.6f} s matches no offset the known merge faults carry "
                              f"into file {list(key)} ({known})")
            carried[key] = offset
        if stored[n] != key or not near(e["from"], new_from) or not near(e["to"], new_to):
            if not near(e["to"] - e["from"], new_to - new_from):
                raise Refused(f"{label}: stored duration differs from its length")
            edits.append({"camera": camera, "episode_index": e["episode_index"], "length": e["length"],
                          "old_file": list(e["file"]), "new_file": list(key),
                          "old_from": e["from"], "old_to": e["to"], "new_from": new_from, "new_to": new_to})
    return edits
