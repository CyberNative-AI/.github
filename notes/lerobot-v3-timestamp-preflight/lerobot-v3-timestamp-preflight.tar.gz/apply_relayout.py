"""Apply a relayout plan (plan_relayout.camera_relayout edits) to one episode table, in memory.

Each edit names one camera and episode with the old and new file (chunk_index, file_index) and the old and
new from/to timestamps. Every old value must equal the table's cell exactly before anything changes; each
cell is edited at most once; column types are kept (integers stay integers, float64 stays float64).
patch_relayout returns the new table and writes nothing; write_relayout writes one new Parquet file.
"""

from collections import defaultdict
import hashlib

import pyarrow as pa
import pyarrow.parquet as pq

from apply_rollover import sha256
from plan_relayout import Refused


def patch_relayout(table, edits, episodes):
    numbers = table["episode_index"].to_pylist()
    if sorted(numbers) != list(range(episodes)):
        raise Refused("episode indices differ from the plan")
    row_of = {value: row for row, value in enumerate(numbers)}
    updates = defaultdict(dict)
    for edit in edits:
        row = row_of[edit["episode_index"]]
        prefix = f"videos/{edit['camera']}/"
        if table["length"][row].as_py() != edit["length"]:
            raise Refused(f"episode {edit['episode_index']}: length differs from the plan")
        cells = {
            prefix + "chunk_index": (edit["old_file"][0], edit["new_file"][0]),
            prefix + "file_index": (edit["old_file"][1], edit["new_file"][1]),
            prefix + "from_timestamp": (edit["old_from"], edit["new_from"]),
            prefix + "to_timestamp": (edit["old_to"], edit["new_to"]),
        }
        for column, (old, new) in cells.items():
            if column not in table.column_names:
                raise Refused(f"missing column {column}")
            if row in updates[column]:
                raise Refused(f"episode {edit['episode_index']}: duplicate edit of {column}")
            if table[column][row].as_py() != old:
                raise Refused(f"episode {edit['episode_index']}: {column} differs from the plan")
            updates[column][row] = new
    for column, replacements in updates.items():
        field = table.schema.field(column)
        if column.endswith("_timestamp"):
            if not pa.types.is_float64(field.type):
                raise Refused(f"{column} is not float64")
            if any(type(v) is not float for v in replacements.values()):
                raise Refused(f"{column}: new value is not a float")
        else:
            if not pa.types.is_integer(field.type):
                raise Refused(f"{column} is not an integer column")
            if any(type(v) is not int or v < 0 for v in replacements.values()):
                raise Refused(f"{column}: new value is not a non-negative int")
        values = table[column].to_pylist()
        for row, value in replacements.items():
            values[row] = value
        table = table.set_column(table.schema.get_field_index(column), field, pa.array(values, type=field.type))
    return table


def write_relayout(source, inventory, plan, output):
    """Write the patched episode Parquet of a verified local archive to output (a new file)."""
    shards = sorted(source.glob("meta/episodes/**/*.parquet"))
    if len(shards) != 1:
        raise Refused("this writer requires one episode Parquet shard")
    relative = shards[0].relative_to(source).as_posix()
    original = shards[0].read_bytes()
    if hashlib.sha256(original).hexdigest() != inventory[relative]["sha256"]:
        raise Refused("episode Parquet changed after snapshot verification")
    if plan.get("kind") != "relayout" or not plan["edits"]:
        raise Refused("no relayout edits")
    table = pq.ParquetFile(pa.BufferReader(original)).read()
    updated = patch_relayout(table, plan["edits"], plan["episodes"])
    if output.exists() or output.is_symlink():
        raise Refused("replacement path already exists")
    pq.write_table(updated, output)
    if not pq.ParquetFile(output).read().equals(updated, check_metadata=True):
        raise Refused("replacement Parquet did not round-trip")
    return {"path": relative, "edits": plan["edits"], "sha256": sha256(output)}
