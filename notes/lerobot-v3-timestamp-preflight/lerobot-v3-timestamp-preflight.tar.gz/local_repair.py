"""Plan and apply a source-bound LeRobot v3 repair (rollover or relayout) to a new local copy."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

from apply_relayout import write_relayout
from apply_rollover import _write_replacement, sha256, verify_snapshot
from local_preflight import check_archive, require


def inventory(root):
    files = {}
    for path in sorted(root.rglob("*")):
        name = path.relative_to(root).as_posix()
        require(not path.is_symlink(), f"archive contains a symbolic link: {name}")
        if path.is_dir():
            continue
        require(path.is_file(), f"archive contains a non-regular file: {name}")
        files[name] = {"size": path.stat().st_size, "sha256": sha256(path)}
    return files


def candidate(root, files):
    shards = sorted(root.glob("meta/episodes/**/*.parquet"))
    require(len(shards) == 1, "this repair requires one episode Parquet shard")
    report, audit = check_archive(root)
    status = report["status"]
    require(
        status in ("rollover_candidate", "relayout_candidate"),
        f"preflight returned {status}; run local_preflight.py for details",
    )
    return {
        "version": 1,
        "episode_parquet": shards[0].relative_to(root).as_posix(),
        "source_files": files,
        "plan": report["plan"],
    }, audit


def prepare(source):
    files = inventory(source)
    prepared, _ = candidate(source, files)
    verify_snapshot(source, files)
    return prepared


def repair_copy(source, candidate_path, output):
    output = output.parent.resolve(strict=True) / output.name
    require(
        not output.is_relative_to(source), "output must be outside the source archive"
    )
    require(not output.exists() and not output.is_symlink(), "output already exists")
    candidate_bytes = candidate_path.read_bytes()
    saved = json.loads(candidate_bytes)
    require(
        isinstance(saved, dict) and saved.get("version") == 1,
        "unsupported candidate format",
    )
    files = inventory(source)
    require(
        files == saved.get("source_files"),
        "source inventory or bytes differ from the saved candidate",
    )

    with TemporaryDirectory(prefix=".lerobot-repair-", dir=output.parent) as temp:
        stage = Path(temp) / "archive"
        shutil.copytree(source, stage, symlinks=True)
        verify_snapshot(stage, files)
        regenerated, audit = candidate(stage, files)
        require(
            regenerated == saved,
            "saved plan differs from preflight on the verified copy",
        )

        manifest = {
            "dataset": regenerated["plan"]["dataset"],
            "revision": "local-sha256:"
            + hashlib.sha256(
                json.dumps(files, sort_keys=True).encode("utf-8")
            ).hexdigest(),
            "files": files,
        }
        replacement = Path(temp) / "episodes.parquet"
        if regenerated["plan"].get("kind") == "relayout":
            receipt = write_relayout(stage, files, regenerated["plan"], replacement)
        else:
            receipt = json.loads(_write_replacement(stage, manifest, audit, replacement))
        relative = regenerated["episode_parquet"]
        require(
            receipt["path"] == relative
            and receipt["edits"] == regenerated["plan"]["edits"],
            "writer result differs from the saved plan",
        )
        repaired_files = {
            **files,
            relative: {
                "size": replacement.stat().st_size,
                "sha256": receipt["sha256"],
            },
        }
        replacement.replace(stage / relative)
        postflight, _ = check_archive(stage)
        require(
            postflight["status"] == "aligned",
            "preflight on the repaired copy did not align",
        )
        verify_snapshot(stage, repaired_files)
        verify_snapshot(source, files)

        # Reserve the destination after verification so concurrent runs cannot claim it twice.
        output.mkdir()
        try:
            stage.replace(output)
        except BaseException:
            if stage.exists():
                output.rmdir()
            raise

    return {
        "status": "aligned",
        "candidate_sha256": hashlib.sha256(candidate_bytes).hexdigest(),
        "unchanged_copy_files": len(files) - 1,
        "replacement": {"path": relative, **repaired_files[relative]},
        "edits": receipt["edits"],
        "preflight": postflight,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    plan = commands.add_parser(
        "plan", help="print a candidate with a SHA-256 inventory"
    )
    plan.add_argument("archive", type=Path)
    copy = commands.add_parser(
        "copy", help="verify a candidate and write a new, aligned copy"
    )
    copy.add_argument("archive", type=Path)
    copy.add_argument("candidate", type=Path)
    copy.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        source = args.archive.resolve(strict=True)
        require(source.is_dir(), "archive must be a directory")
        if args.command == "plan":
            result = prepare(source)
        else:
            result = repair_copy(source, args.candidate, args.output)
    except (OSError, TypeError, ValueError, KeyError) as exc:
        parser.exit(2, f"Refused: {exc}\n")
    except Exception as exc:  # report any other failure as a refusal, not a traceback
        parser.exit(2, f"Refused: unexpected {type(exc).__name__}: {exc}\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
