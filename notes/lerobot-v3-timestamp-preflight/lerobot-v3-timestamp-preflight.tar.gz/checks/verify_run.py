"""Decide a check run's result from its written summary and output files.

usage: verify_run.py OUTPUT_DIRECTORY EXPECTED-OUTPUTS.sha256

Passes only if every summary line is a JSON object with exactly a string "step"
and an integer "rc", the steps are exactly the planned ones in order, each rc is
0, and every expected output is a regular file with the listed SHA-256.
"""

from hashlib import file_digest
import json
from pathlib import Path
import sys

STEPS = ("env", "unit", "demo", "merge", "preflight", "copy", "multicam")


def fail(message):
    print(f"FAIL {message}", file=sys.stderr)
    raise SystemExit(1)


def unique_keys(pairs):
    names = [name for name, _ in pairs]
    if len(set(names)) != len(names):
        raise ValueError(f"repeated key in {names}")
    return dict(pairs)


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    out, expected = Path(sys.argv[1]), Path(sys.argv[2])
    try:
        rows = [
            json.loads(line, object_pairs_hook=unique_keys)
            for line in (out / "summary.jsonl").read_text().splitlines()
        ]
    except (OSError, ValueError) as exc:
        fail(f"summary unreadable: {exc}")
    for number, row in enumerate(rows, 1):
        if not (
            type(row) is dict
            and row.keys() == {"step", "rc"}
            and type(row["step"]) is str
            and type(row["rc"]) is int
        ):
            fail(f"summary line {number} is not a step record: {row!r}")
    if [row["step"] for row in rows] != list(STEPS):
        fail(f"summary steps {[row['step'] for row in rows]} differ from {list(STEPS)}")
    for row in rows:
        if row["rc"] != 0:
            fail(f"step {row['step']} exited {row['rc']}")
    listed = []
    for line in expected.read_text().splitlines():
        digest, separator, name = line.partition("  ")
        if not (separator and len(digest) == 64 and name):
            fail(f"malformed line in {expected}: {line!r}")
        path = out / name
        if path.is_symlink() or not path.is_file():
            fail(f"missing output {name}")
        with path.open("rb") as stream:
            actual = file_digest(stream, "sha256").hexdigest()
        if actual != digest:
            fail(f"{name} has SHA-256 {actual}, expected {digest}")
        listed.append(name)
    if not listed:
        fail("no expected outputs listed")
    print(f"OK {len(rows)} steps passed; {len(listed)} outputs match EXPECTED-OUTPUTS.sha256")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
