"""Replay the local preflight on the generated archives and controls.

usage: check_preflight.py DEMO MERGE

DEMO is the output directory of replay.py and MERGE the output directory of
replay_merge.py. Every kit command runs through guard.py.
"""

import argparse
from decimal import Decimal
import json
import os
import shutil
import subprocess
import sys
from hashlib import file_digest
from pathlib import Path
from tempfile import TemporaryDirectory

import pyarrow as pa
import pyarrow.parquet as pq

KIT = Path(__file__).resolve().parents[1]
PREFLIGHT = KIT / "local_preflight.py"
REPAIR = KIT / "local_repair.py"
GUARD = Path(__file__).resolve().with_name("guard.py")


class CheckFailed(Exception):
    pass


def require(condition, message):
    if not condition:
        raise CheckFailed(message)


def inventory(root):
    hashes = {}
    for path in sorted(root.rglob("*")):
        if path.is_file():
            with path.open("rb") as stream:
                hashes[path.relative_to(root)] = file_digest(
                    stream, "sha256"
                ).hexdigest()
    return hashes


def guarded(script, *args):
    command = [sys.executable, "-B", str(GUARD), str(script), *map(str, args)]
    return subprocess.run(command, capture_output=True, check=False)


def run(root, status, exit_code):
    before = inventory(root)
    first, second = [guarded(PREFLIGHT, root) for _ in range(2)]
    require(
        first.returncode == second.returncode == exit_code,
        (first.returncode, second.returncode, first.stderr.decode()),
    )
    require(
        first.stdout == second.stdout and not first.stderr and not second.stderr,
        f"preflight output differs between runs on {root.name}",
    )
    require(inventory(root) == before, f"preflight changed {root.name}")
    report = json.loads(first.stdout)
    require(report["status"] == status, report["status"])
    return report


def drift_cell(file, column, row):
    table = pq.ParquetFile(file).read()
    index = table.schema.get_field_index(column)
    field = table.schema.field(index)
    values = table[column].to_pylist()
    values[row] += 0.00007
    pq.write_table(
        table.set_column(index, field, pa.array(values, type=field.type)), file
    )


def linked_tree(source, target):
    """Mirror SOURCE as directories of absolute symbolic links, like a Hub cache snapshot."""
    for path in sorted(source.rglob("*")):
        relative = path.relative_to(source)
        if path.is_dir():
            (target / relative).mkdir(parents=True)
        else:
            os.symlink(path, target / relative)


MALFORMED = {
    # name: (change to the clean archive, text the single issue's detail must contain)
    "data_path_positional": (
        lambda info: info.update(data_path="data/{0}.parquet"),
        "unsupported data path template",
    ),
    "video_path_width": (
        lambda info: info.update(
            video_path="videos/{video_key}/{chunk_index:>999999999}/{file_index}.mp4"
        ),
        "unsupported videos path template",
    ),
    "info_not_json": ("{", "Expecting property name"),
    "info_nested_too_deep": ("[" * 100000 + "]" * 100000, "RecursionError"),
}

TYPED = {
    # name: (Parquet files, column-name suffix, text the single issue's detail must contain).
    # The column's values are rewritten as decimal128(18, 9) on the rollover archive.
    "camera_end_decimal": (
        "meta/episodes/*/*.parquet",
        "/to_timestamp",
        "invalid camera timestamps",
    ),
    "row_timestamp_decimal": (
        "data/*/*.parquet",
        "timestamp",
        "invalid identity or timestamp at frame 0",
    ),
}

# Planted faults inside the tools, run through the guard: name -> probe source.
# Each probe gets the kit directory and an archive as arguments.
FALLBACK_PROBES = {
    "preflight_unencodable_report": """
import sys
from decimal import Decimal
sys.path.insert(0, sys.argv[1])
import local_preflight
original = local_preflight.preflight
def planted(root, report):
    records = original(root, report)
    report["affected_episodes"].append({"planted": Decimal("1.5")})
    return records
local_preflight.preflight = planted
sys.argv = ["local_preflight.py", sys.argv[2]]
raise SystemExit(local_preflight.main())
""",
    "repair_unexpected_error": """
import sys
sys.path.insert(0, sys.argv[1])
import local_repair
def planted(source):
    raise RuntimeError("planted failure")
local_repair.prepare = planted
sys.argv = ["local_repair.py", "plan", sys.argv[2]]
local_repair.main()
""",
}

GUARD_PROBES = {
    "socket": ("import socket\nsocket.socket()\n", "socket.__new__"),
    "urllib": (
        "import urllib.request\nurllib.request.urlopen('http://127.0.0.1:9/')\n",
        "urllib.Request",
    ),
    "subprocess": ("import subprocess\nsubprocess.run(['true'])\n", "subprocess.Popen"),
    "os.system": ("import os\nos.system('true')\n", "os.system"),
}


def malformed(clean, tmp):
    """Each malformed copy must give needs_review as JSON, exit 2, and stay unchanged."""
    codes = {}
    for name, (change, detail) in MALFORMED.items():
        root = tmp / f"malformed-{name}"
        shutil.copytree(clean, root)
        info_file = root / "meta/info.json"
        if callable(change):
            info = json.loads(info_file.read_text(encoding="utf-8"))
            change(info)
            info_file.write_text(json.dumps(info, indent=4), encoding="utf-8")
        else:
            info_file.write_text(change, encoding="utf-8")
        report = run(root, "needs_review", 2)
        issues = report["issues"]
        require(
            len(issues) == 1
            and issues[0]["code"] == "archive_unreadable_or_inconsistent"
            and detail in issues[0]["detail"]
            and "plan" not in report,
            (name, issues),
        )
        codes[name] = issues[0]["code"]
    return codes


def typed(rollover, tmp):
    """A timestamp stored as a decimal must give needs_review as JSON, exit 2, and no change."""
    codes = {}
    for name, (pattern, suffix, detail) in TYPED.items():
        root = tmp / f"typed-{name}"
        shutil.copytree(rollover, root)
        changed = 0
        for file in sorted(root.glob(pattern)):
            table = pq.ParquetFile(file).read()
            for column in [c for c in table.column_names if c.endswith(suffix)]:
                values = [
                    Decimal(repr(value)).quantize(Decimal("1e-9"))
                    for value in table[column].to_pylist()
                ]
                table = table.set_column(
                    table.schema.get_field_index(column),
                    column,
                    pa.array(values, type=pa.decimal128(18, 9)),
                )
                changed += 1
            pq.write_table(table, file)
        require(changed >= 1, (name, "no column rewritten"))
        report = run(root, "needs_review", 2)
        issues = report["issues"]
        require(
            len(issues) == 1
            and issues[0]["code"] == "archive_unreadable_or_inconsistent"
            and detail in issues[0]["detail"]
            and "plan" not in report,
            (name, issues),
        )
        codes[name] = issues[0]["code"]
    return codes


def fallback_controls(archive, tmp):
    """The last-resort paths: a report that cannot be encoded, and an unexpected repair error."""
    before = inventory(archive)
    results = {}
    for name, source in FALLBACK_PROBES.items():
        probe = tmp / f"probe-{name}.py"
        probe.write_text(source, encoding="utf-8")
        results[name] = guarded(probe, KIT, archive)
        require(inventory(archive) == before, (name, "changed the archive"))
    planted = results["preflight_unencodable_report"]
    report = json.loads(planted.stdout)
    require(
        planted.returncode == 2
        and not planted.stderr
        and report["status"] == "needs_review"
        and report["affected_episodes"] == []
        and [issue["code"] for issue in report["issues"]]
        == ["archive_unreadable_or_inconsistent"]
        and report["issues"][0]["detail"].startswith("report not encodable as JSON: TypeError")
        and "plan" not in report,
        ("unencodable report", planted.returncode, planted.stderr.decode(), report),
    )
    repair = results["repair_unexpected_error"]
    message = b"Refused: unexpected RuntimeError: planted failure\n"
    require(
        repair.returncode == 2 and not repair.stdout and repair.stderr == message,
        ("repair fallback", repair.returncode, repair.stderr.decode()),
    )
    return {
        "preflight_unencodable_report": report["issues"][0]["code"],
        "repair_unexpected_error": message.decode().strip(),
    }


def guard_controls(tmp):
    blocked = {}
    for name, (source, event) in GUARD_PROBES.items():
        probe = tmp / f"probe-{name.replace('.', '-')}.py"
        probe.write_text(source, encoding="utf-8")
        result = guarded(probe)
        require(
            result.returncode != 0
            and f"guard blocked {event}".encode() in result.stderr,
            ("guard control", name, result.returncode, result.stderr.decode()),
        )
        blocked[name] = event
    return blocked


def check(demo, merge):
    clean = run(demo / "repaired", "aligned", 0)
    require(
        clean["affected_episodes"] == clean["issues"] == [] and "plan" not in clean,
        "clean archive reported a problem",
    )

    rollover = run(demo / "original", "rollover_candidate", 0)
    expected = json.loads((demo / "result.json").read_text())["edit"]
    require(
        rollover["plan"]["edits"] == [expected] and rollover["issues"] == [],
        "rollover plan differs from the planted edit",
    )
    require(len(rollover["affected_episodes"]) == 1, rollover["affected_episodes"])
    (affected,) = rollover["affected_episodes"]
    require(
        (
            affected["camera"],
            affected["episode"],
            affected["queries_off_any_sample"],
            affected["queries_off_packed_time"],
        )
        == (expected["camera"], 2, 7, 7),
        affected,
    )

    merged = run(merge / "original_then_control", "needs_review", 2)
    require(len(merged["affected_episodes"]) == 1, merged["affected_episodes"])
    (affected,) = merged["affected_episodes"]
    require(
        (
            affected["episode"],
            affected["queries_off_any_sample"],
            affected["queries_off_packed_time"],
        )
        == (2, 0, 7),
        affected,
    )
    require(
        merged["issues"][0]["code"] == "unsupported_timestamp_pattern"
        and "plan" not in merged,
        merged["issues"],
    )
    merged_clean = run(merge / "repaired_then_control", "aligned", 0)
    require(
        merged_clean["counts"]["stored_tabular_rows"] == 38
        and not merged_clean["affected_episodes"],
        merged_clean["counts"],
    )

    with TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        drifted = tmp / "drifted"
        shutil.copytree(demo / "repaired", drifted)
        episode_file = next((drifted / "meta/episodes").glob("*/*.parquet"))
        data_file = next((drifted / "data").glob("*/*.parquet"))
        drift_cell(episode_file, f"videos/{expected['camera']}/from_timestamp", 2)
        drift_cell(data_file, "timestamp", 17)
        residual = run(drifted, "needs_review", 2)

        linked = tmp / "linked"
        linked_tree(demo / "original", linked)
        linked_report = run(linked, "rollover_candidate", 0)
        require(linked_report == rollover, "linked tree changed the report")
        refused = guarded(REPAIR, "plan", linked)
        require(
            refused.returncode == 2
            and not refused.stdout
            and b"archive contains a symbolic link" in refused.stderr,
            (refused.returncode, refused.stderr.decode()),
        )
        linked_refusal = refused.stderr.decode().strip().removeprefix("Refused: ")
        linked_refusal = linked_refusal.split(": ")[0]

        # A link to the archive directory itself is resolved first, then the tree is checked.
        alias = tmp / "alias"
        alias.symlink_to(demo / "original", target_is_directory=True)
        before = inventory(demo / "original")
        direct = guarded(REPAIR, "plan", demo / "original")
        aliased = guarded(REPAIR, "plan", alias)
        require(
            direct.returncode == aliased.returncode == 0
            and direct.stdout == aliased.stdout
            and not direct.stderr
            and not aliased.stderr
            and inventory(demo / "original") == before,
            ("root alias", aliased.returncode, aliased.stderr.decode()),
        )

        malformed_codes = malformed(demo / "repaired", tmp)
        typed_codes = typed(demo / "original", tmp)
        fallbacks = fallback_controls(demo / "original", tmp)
        blocked = guard_controls(tmp)
    require(
        residual["issues"]
        == [
            {
                "code": "unresolved_stored_queries",
                "camera": expected["camera"],
                "episode": 2,
                "rows": 1,
            }
        ]
        and "plan" not in residual,
        residual["issues"],
    )
    result = {
        "clean": clean,
        "rollover": rollover,
        "merged": merged,
        "merged_clean": merged_clean,
        "residual": residual,
        "linked": {
            "preflight_equals_rollover": True,
            "repair_plan_refusal": linked_refusal,
            "root_alias_plan_equals_direct": True,
        },
        "malformed": malformed_codes,
        "typed": typed_codes,
        "fallbacks": fallbacks,
        "guard_blocked": blocked,
    }
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("demo", type=Path)
    parser.add_argument("merge", type=Path)
    args = parser.parse_args()
    print(json.dumps(check(args.demo.resolve(), args.merge.resolve()), indent=2))
