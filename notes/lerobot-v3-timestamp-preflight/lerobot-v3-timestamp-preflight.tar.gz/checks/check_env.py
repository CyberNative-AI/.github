"""Check Python 3.12.16, the installed versions against the exact pins, and load both decoders.

merge/result.json records the Python version, so its expected SHA-256 holds only on 3.12.16.

usage: check_env.py requirements.txt
"""

from importlib.metadata import PackageNotFoundError, version
import json
import re
import sys

import av  # Load PyAV's FFmpeg before TorchCodec.

PIN = re.compile(r"^([A-Za-z0-9_.-]+)(?:\[[A-Za-z0-9_,.-]+\])?==(\S+)$")


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    problems, found = [], {}
    with open(sys.argv[1], encoding="utf-8") as stream:
        for line in stream:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            match = PIN.match(line)
            if not match:
                problems.append(f"not an exact pin: {line}")
                continue
            name, wanted = match.groups()
            try:
                found[name] = version(name)
            except PackageNotFoundError:
                problems.append(f"{name} is not installed")
                continue
            if found[name] != wanted:
                problems.append(f"{name} {found[name]} is installed; the checks expect {wanted}")
    if sys.version_info[:5] != (3, 12, 16, "final", 0):
        problems.append(f"Python {sys.version.split()[0]}; the checks expect 3.12.16")
    try:
        from torchcodec.decoders import VideoDecoder  # noqa: F401
    except Exception as exc:  # report every load failure the same way
        problems.append(f"TorchCodec cannot load FFmpeg: {exc}")
    print(json.dumps({"python": sys.version.split()[0], "av": av.__version__, "packages": found}))
    if problems:
        print("\n".join(problems), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
