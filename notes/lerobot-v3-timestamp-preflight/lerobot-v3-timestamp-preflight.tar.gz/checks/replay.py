"""Generate and replay a three-episode LeRobot v3 rollover fixture on CPU."""

import argparse
from collections import defaultdict
from importlib.metadata import version
from itertools import accumulate
import json
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

import av  # Load PyAV's FFmpeg before LeRobot can import TorchCodec.
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from lerobot.configs.video import RGBEncoderConfig
from lerobot.datasets.dataset_tools import merge_datasets
from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lerobot.datasets.video_utils import FrameTimestampError

from apply_rollover import _write_replacement, sha256, verify_snapshot
from moovpts import parse, sorted_seconds
from plan_rollover import build_plan


DATASET = "synthetic/rollover"
CAMERA = "observation.images.camera"
VIDEO = f"videos/{CAMERA}/"
FPS = 8
LENGTHS = (12, 5, 7)
SIDE = 128
EPISODES = Path("meta/episodes/chunk-000/file-000.parquet")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def frame_image(serial):
    # 4-by-4 pixel blocks encode the same serial as observation.state.
    image = np.zeros((SIDE, SIDE, 3), dtype=np.uint8)
    for bit in range(16):
        row, col = divmod(bit, 4)
        if serial & (1 << bit):
            image[row * 32 + 4:(row + 1) * 32 - 4, col * 32 + 4:(col + 1) * 32 - 4] = 255
    return image


def read_serial(image):
    gray = image.numpy().mean(axis=0)
    serial = 0
    for bit in range(16):
        row, col = divmod(bit, 4)
        middle = gray[row * 32 + 10:(row + 1) * 32 - 10, col * 32 + 10:(col + 1) * 32 - 10]
        if middle.mean() > 127:
            serial |= 1 << bit
    return serial


def generate(root, scratch):
    features = {
        CAMERA: {"dtype": "video", "shape": (SIDE, SIDE, 3), "names": ["height", "width", "channels"]},
        "observation.state": {"dtype": "float32", "shape": (1,), "names": ["serial"]},
        "action": {"dtype": "float32", "shape": (1,), "names": ["unused"]},
    }
    sources = []
    serial = 1
    for shard, lengths in enumerate((LENGTHS[:1], LENGTHS[1:])):
        source = LeRobotDataset.create(
            f"synthetic/shard-{shard}", FPS, features, root=scratch / f"shard-{shard}",
            rgb_encoder=RGBEncoderConfig(vcodec="h264"), encoder_threads=1, video_backend="pyav",
        )
        for length in lengths:
            for _ in range(length):
                source.add_frame({CAMERA: frame_image(serial), "task": "read the frame serial",
                                  "observation.state": np.array([serial], dtype=np.float32),
                                  "action": np.zeros(1, dtype=np.float32)})
                serial += 1
            source.save_episode(parallel_encoding=False)
        source.finalize()
        sources.append(source)
    merge_datasets(sources, DATASET, root, concatenate_videos=False)
    clean = pq.ParquetFile(root / EPISODES).read()
    require(clean["episode_index"].to_pylist() == [0, 1, 2], "unexpected episode order")
    require(clean["length"].to_pylist() == list(LENGTHS), "unexpected episode lengths")
    require(clean[VIDEO + "chunk_index"].to_pylist() == [0, 0, 0]
            and clean[VIDEO + "file_index"].to_pylist() == [0, 1, 1], "expected the 1+2 file layout")
    broken = clean
    # Model the measured signature by carrying the first file's duration into episode 2.
    for endpoint in ("from", "to"):
        name = VIDEO + endpoint + "_timestamp"
        values = clean[name].to_pylist()
        values[2] += LENGTHS[0] / FPS
        index = clean.schema.get_field_index(name)
        field = clean.schema.field(index)
        broken = broken.set_column(index, field, pa.array(values, type=field.type))
    pq.write_table(broken, root / EPISODES)
    return clean


def audit(root, table):
    info = json.loads((root / "meta/info.json").read_text())
    files = sorted((root / "videos").rglob("*.mp4"))
    require(len(files) == 2, "expected two stored MP4s")
    points = {}
    rows = []
    counts = defaultdict(int)
    for row in table.to_pylist():
        key = (row[VIDEO + "chunk_index"], row[VIDEO + "file_index"])
        if key not in points:
            path = root / info["video_path"].format(video_key=CAMERA, chunk_index=key[0], file_index=key[1])
            with path.open("rb") as stream:
                points[key] = sorted_seconds(parse(stream))
            require(all(abs(pts - i / FPS) <= 1e-4 for i, pts in enumerate(points[key])),
                    f"unexpected MP4 presentation grid in {path.name}")
        times = points[key]
        start = counts[key]
        end = start + row["length"]
        require(end <= len(times), "episode extends beyond stored frames")
        counts[key] = end
        rows.append({"ep": row["episode_index"], "file": list(key), "pos": start, "len": row["length"],
                     "from": row[VIDEO + "from_timestamp"], "to": row[VIDEO + "to_timestamp"],
                     "real_from": times[start], "real_to": times[end - 1] + 1 / FPS})
    records = [{"check": "info", "version": info["codebase_version"], "video_keys": [CAMERA],
                "fps": info["fps"], "total_episodes": info["total_episodes"],
                "total_frames": info["total_frames"]},
               {"check": "episodes", "vk": CAMERA, "fps": info["fps"], "rows": rows}]
    for key, times in points.items():
        records.append({"check": "file", "vk": CAMERA, "file": list(key), "container": len(times),
                        "meta": counts[key], "first_pts": times[0], "end": times[-1] + 1 / FPS})
    return [{"ds": DATASET, **record} for record in [*records, {"check": "ds_done"}]]


def inventory(root):
    return {path.relative_to(root).as_posix(): {"size": path.stat().st_size, "sha256": sha256(path)}
            for path in sorted(root.rglob("*")) if path.is_file()}


def read_datasets(original, repaired, backend):
    readers = [LeRobotDataset(DATASET, root=root, video_backend=backend, return_uint8=True, token=False)
               for root in (original, repaired)]
    total = sum(LENGTHS)
    require(all(len(ds) == total for ds in readers), f"{backend}: wrong dataset length")
    expected_error = {"pyav": FrameTimestampError, "torchcodec": IndexError}[backend]
    first_join, second_join, _ = accumulate(LENGTHS)
    sample_rows = {0, first_join - 1, first_join, second_join - 1, second_join, total - 1}
    failures = []
    boundaries = []
    for index in range(total):
        expected = index + 1
        outcomes = []
        for stage, ds in zip(("original", "repaired"), readers, strict=True):
            try:
                item = ds[index]
            except expected_error as exc:
                if stage != "original" or index < second_join:
                    raise
                outcomes.append(type(exc).__name__)
                failures.append(index)
                continue
            require(stage == "repaired" or index < second_join, f"{backend}: corrupt row {index} unexpectedly read")
            serial = float(item["observation.state"].reshape(-1)[0])
            require(serial == read_serial(item[CAMERA]) == expected,
                    f"{backend}: {stage} row {index} has the wrong tabular or image serial")
            outcomes.append(expected)
        if index in sample_rows:
            boundaries.append({"row": index, "original": outcomes[0], "repaired": outcomes[1]})
    return {"original_failed_rows": failures, "repaired_matches": total, "boundaries": boundaries}


def replay(output):
    original = output / "original"
    with TemporaryDirectory(dir=output) as scratch:
        clean = generate(original, Path(scratch))
    table = pq.ParquetFile(original / EPISODES).read()
    records = audit(original, table)
    require(build_plan(audit(original, clean), DATASET)["edits"] == [], "clean control generated an edit")
    edits = build_plan(records, DATASET)["edits"]
    require(len(edits) == 1 and edits[0]["episode_index"] == 2, "expected one episode edit")
    source_files = inventory(original)
    manifest = {"dataset": DATASET, "revision": "generated-v1", "files": source_files}
    replacement = output / "replacement.parquet"
    # The kit's CLI stays hash-pinned to the public archive. Exercise its same writer
    # on the generated source and inventory, through this fixture's fixed workflow.
    receipt = json.loads(_write_replacement(original, manifest, records, replacement))
    require(pq.ParquetFile(replacement).read().equals(clean, check_metadata=True),
            "replacement must restore the full clean episode table and schema")
    repaired = output / "repaired"
    shutil.copytree(original, repaired)
    shutil.copyfile(replacement, repaired / EPISODES)
    reads = {backend: read_datasets(original, repaired, backend) for backend in ("pyav", "torchcodec")}
    verify_snapshot(original, source_files)
    verify_snapshot(repaired, {**source_files, EPISODES.as_posix(): {
        "size": replacement.stat().st_size, "sha256": receipt["sha256"],
    }})
    (output / "audit.json").write_text(json.dumps(records, indent=2) + "\n")
    (output / "apply.json").write_text(json.dumps(receipt, indent=2) + "\n")
    report = {"lerobot": version("lerobot"), "fps": FPS, "episode_lengths": LENGTHS,
              "video_files": 2, "source_bytes": sum(file["size"] for file in source_files.values()),
              "unchanged_files": len(source_files) - 1, "edit": edits[0], "reads": reads}
    result = json.dumps(report, indent=2)
    (output / "result.json").write_text(result + "\n")
    print(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new local output directory")
    args = parser.parse_args()
    require(version("lerobot") == "0.7.0", "this replay requires LeRobot 0.7.0")
    require(av.__version__ == "15.1.0", "this replay requires PyAV 15.1.0")
    torch.set_num_threads(2)
    args.output.mkdir()
    replay(args.output.resolve())


if __name__ == "__main__":
    main()
