"""Two cameras with different file and rollover boundaries: repair a copy, merge it, read every frame.

LeRobot 0.7.0's own recorder writes the fixture with a small video file size limit. The wrist
camera's frames carry seeded noise, so its files reach the limit sooner and each camera gets its
own file boundaries, as in a public two-camera archive. The limit is chosen from a calibration
recording (one episode per file) by simulating the recorder's size rule, then checked on the real
recording. The measured rollover signature is planted per camera at different episodes. The
unchanged local_preflight.py and local_repair.py repair a copy. LeRobot's merge CLI then merges
the original and the repaired copy with a clean two-camera control. Every row is read on PyAV and
TorchCodec, through the ordinary item path and per camera.
"""

import argparse
from collections import Counter
from importlib.metadata import version
import json
import math
from pathlib import Path
import subprocess
import sys

import av  # Load PyAV's FFmpeg before LeRobot can import TorchCodec.
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import torch
from lerobot.configs.video import RGBEncoderConfig
from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lerobot.datasets.video_utils import FrameTimestampError

from replay import frame_image, inventory, read_serial, require


KIT = Path(__file__).resolve().parents[1]
GUARD = Path(__file__).resolve().with_name("guard.py")
DATASET = "synthetic/two-camera-rollover"
CONTROL = "synthetic/two-camera-control"
FRONT, WRIST = "observation.images.front", "observation.images.wrist"
CAMERAS = (FRONT, WRIST)
FPS = 8
SIDE = 128
LENGTHS = (9, 6, 11, 7, 5, 10, 8, 6)
CONTROL_LENGTHS = (7, 5)
# Fixed order of (front, wrist) noise amplitudes; the first that yields the layout is used.
NOISE_PAIRS = ((24, 40), (32, 48), (16, 32), (40, 64), (24, 64), (48, 64))
EPISODES = Path("meta/episodes/chunk-000/file-000.parquet")
BACKENDS = ("pyav", "torchcodec")
DECODE_ERRORS = (FrameTimestampError, IndexError, RuntimeError)


def image(camera, serial, noise):
    amplitude = noise[CAMERAS.index(camera)]
    base = frame_image(serial).astype(np.int16)
    if amplitude:
        rng = np.random.default_rng([serial, CAMERAS.index(camera)])
        base += rng.integers(-amplitude, amplitude + 1, size=base.shape[:2], dtype=np.int16)[..., None]
    return np.clip(base, 0, 255).astype(np.uint8)


def features():
    video = {"dtype": "video", "shape": (SIDE, SIDE, 3), "names": ["height", "width", "channels"]}
    return {FRONT: dict(video), WRIST: dict(video),
            "observation.state": {"dtype": "float32", "shape": (1,), "names": ["serial"]},
            "action": {"dtype": "float32", "shape": (1,), "names": ["unused"]}}


def record(root, repo_id, lengths, first_serial, noise, limit_mb=None):
    dataset = LeRobotDataset.create(
        repo_id, FPS, features(), root=root, video_files_size_in_mb=limit_mb,
        rgb_encoder=RGBEncoderConfig(vcodec="h264"), encoder_threads=1, video_backend="pyav",
    )
    serial = first_serial
    for length in lengths:
        for _ in range(length):
            dataset.add_frame({**{camera: image(camera, serial, noise) for camera in CAMERAS},
                               "task": "read the frame serial",
                               "observation.state": np.array([serial], dtype=np.float32),
                               "action": np.zeros(1, dtype=np.float32)})
            serial += 1
        dataset.save_episode(parallel_encoding=False)
    dataset.finalize()
    shards = sorted(root.glob("meta/episodes/**/*.parquet"))
    require(shards == [root / EPISODES], "expected one episode Parquet shard")
    return pq.ParquetFile(root / EPISODES).read()


def layout(table):
    """Per camera: the file of each episode, in episode order."""
    require(table["episode_index"].to_pylist() == list(range(table.num_rows)), "unexpected episode order")
    return {camera: [(c, f) for c, f in zip(table[f"videos/{camera}/chunk_index"].to_pylist(),
                                              table[f"videos/{camera}/file_index"].to_pylist(), strict=True)]
            for camera in CAMERAS}


def groups(files):
    """Episode indices grouped by file, in file order."""
    out = []
    for episode, key in enumerate(files):
        if not out or out[-1][0] != key:
            out.append((key, []))
        out[-1][1].append(episode)
    return out


def plant_targets(files):
    """The tail of the first later file with at least two episodes: the measured signature."""
    for position, (_, episodes) in enumerate(groups(files)):
        if position and len(episodes) >= 2:
            return episodes[1:]
    return None


def layout_ok(per_camera):
    starts = {camera: tuple(episodes[0] for _, episodes in groups(files)) for camera, files in per_camera.items()}
    targets = {camera: plant_targets(files) for camera, files in per_camera.items()}
    return (all(len(value) >= 2 for value in starts.values())
            and starts[FRONT] != starts[WRIST]
            and all(targets.values())
            and targets[FRONT][0] != targets[WRIST][0])


def simulate(sizes, limit):
    """LeRobot 0.7.0 recorder rule per camera; concatenated size approximated by the sum."""
    files, margins, current, file_index = [], [], None, 0
    for size in sizes:
        if current is None:
            current = size
        else:
            margins.append(abs(current + size - limit) / limit)
            if current + size >= limit:
                file_index += 1
                current = size
            else:
                current += size
        files.append((0, file_index))
    return files, margins


def choose_limit(calibration_root):
    info = json.loads((calibration_root / "meta/info.json").read_text())
    table = pq.ParquetFile(calibration_root / EPISODES).read()
    per_camera = layout(table)
    sizes = {}
    for camera, files in per_camera.items():
        require(len(set(files)) == len(files), "calibration must hold one episode per file")
        sizes[camera] = [(calibration_root / info["video_path"].format(
            video_key=camera, chunk_index=c, file_index=f)).stat().st_size / (1024 * 1024) for c, f in files]
    low, high = min(sizes[WRIST]), sum(sizes[FRONT]) + sum(sizes[WRIST])
    best = None
    for step in range(400):
        limit = low * (high / low) ** (step / 399)
        simulated = {camera: simulate(sizes[camera], limit) for camera in CAMERAS}
        if not layout_ok({camera: files for camera, (files, _) in simulated.items()}):
            continue
        margin = min(m for _, margins in simulated.values() for m in margins)
        if best is None or margin > best[0]:
            best = (margin, limit)
    return sizes, best


def plant(clean, targets, per_camera):
    broken = clean
    planted = {}
    for camera in CAMERAS:
        frames_before = 0
        target_file = per_camera[camera][targets[camera][0]]
        for key, episodes in groups(per_camera[camera]):
            if key == target_file:
                break
            frames_before += sum(LENGTHS[episode] for episode in episodes)
        carry = frames_before / FPS
        for endpoint in ("from", "to"):
            name = f"videos/{camera}/{endpoint}_timestamp"
            values = broken[name].to_pylist()
            for episode in targets[camera]:
                values[episode] += carry
            index = broken.schema.get_field_index(name)
            broken = broken.set_column(index, broken.schema.field(index), pa.array(values, type=broken.schema.field(index).type))
        planted[camera] = {"episodes": targets[camera], "carry_s": carry}
    return broken, planted


def run(script, *args):
    return subprocess.run([sys.executable, "-B", str(GUARD), str(KIT / script), *map(str, args)],
                          capture_output=True, check=False)


def read_json(result):
    require(result.returncode == 0, result.stderr.decode())
    return json.loads(result.stdout)


def row_starts(lengths):
    starts, row = [], 0
    for length in lengths:
        starts.append(row)
        row += length
    return starts


def scan(root, repo_id, backend, lengths, first_serial, report_rows):
    dataset = LeRobotDataset(repo_id, root=root, video_backend=backend, return_uint8=True, token=False)
    require(len(dataset) == sum(lengths), "unexpected row count")
    reader = dataset._ensure_reader()  # Per-camera query: the same decode path as dataset[row].
    data = [row for path in sorted(root.glob("data/**/*.parquet")) for row in pq.ParquetFile(path).read().to_pylist()]
    require(len(data) == sum(lengths), "unexpected tabular row count")
    item_counts = Counter(matched=0, wrong_frame=0, decoder_error=0)
    camera_counts = {camera: Counter(matched=0, wrong_frame=0, decoder_error=0) for camera in CAMERAS}
    failures, rows = [], {}
    starts = row_starts(lengths)
    for row in range(sum(lengths)):
        expected = first_serial + row
        episode = max(e for e, start in enumerate(starts) if start <= row)
        record_ = data[row]
        require((record_["index"], record_["episode_index"], record_["frame_index"])
                == (row, episode, row - starts[episode]), f"unexpected tabular identity at row {row}")
        state = record_["observation.state"]
        state = state[0] if isinstance(state, list) else state  # 0.7.0 stores shape (1,) as a scalar
        require(float(state) == expected, f"unexpected tabular serial at row {row}")
        outcome = {"expected": expected}
        try:
            item = dataset[row]
        except DECODE_ERRORS as error:
            outcome["item"] = type(error).__name__
            item_counts["decoder_error"] += 1
        else:
            require(float(item["observation.state"].reshape(-1)[0]) == expected, f"item serial at row {row}")
            decoded = {camera: read_serial(item[camera]) for camera in CAMERAS}
            outcome["item"] = decoded
            item_counts["matched" if all(v == expected for v in decoded.values()) else "wrong_frame"] += 1
        for camera in CAMERAS:
            try:
                frame = reader._query_videos({camera: [record_["timestamp"]]}, episode)[camera]
            except DECODE_ERRORS as error:
                outcome[camera] = type(error).__name__
                camera_counts[camera]["decoder_error"] += 1
                failures.append({"row": row, "camera": camera, "error": outcome[camera]})
                continue
            outcome[camera] = read_serial(frame)
            if outcome[camera] == expected:
                camera_counts[camera]["matched"] += 1
            else:
                camera_counts[camera]["wrong_frame"] += 1
                failures.append({"row": row, "camera": camera, "decoded": outcome[camera]})
        if row in report_rows:
            rows[row] = {"labels": report_rows[row], **outcome}
    return {"item": dict(item_counts), "camera": {k: dict(v) for k, v in camera_counts.items()},
            "failures": failures, "boundary_rows": rows}


def boundary_rows(per_camera, planted):
    """Rows on both sides of every file change and rollover, per camera, plus endpoints."""
    starts = row_starts(LENGTHS)
    labels = {}

    def add(row, label):
        labels.setdefault(row, []).append(label)

    add(0, "first row")
    add(sum(LENGTHS) - 1, "last fixture row")
    for camera in CAMERAS:
        short = camera.rsplit(".", 1)[-1]
        for _, episodes in groups(per_camera[camera])[1:]:
            add(starts[episodes[0]] - 1, f"{short} before file change")
            add(starts[episodes[0]], f"{short} after file change")
        first_bad = planted[camera]["episodes"][0]
        add(starts[first_bad] - 1, f"{short} before rollover")
        add(starts[first_bad], f"{short} after rollover")
        last_bad = planted[camera]["episodes"][-1]
        end = starts[last_bad] + LENGTHS[last_bad]
        add(end - 1, f"{short} last planted row")
        if end < sum(LENGTHS):
            add(end, f"{short} row after planted tail")
    return labels


def planted_rows(planted):
    starts = row_starts(LENGTHS)
    return {camera: sorted(row for episode in value["episodes"]
                           for row in range(starts[episode], starts[episode] + LENGTHS[episode]))
            for camera, value in planted.items()}


def check(work):
    calibration, attempts = None, []
    for noise in NOISE_PAIRS:
        calibration_root = work / f"calibration-{noise[0]}-{noise[1]}"
        record(calibration_root, "synthetic/calibration", LENGTHS, 1, noise, limit_mb=1e-6)
        sizes, best = choose_limit(calibration_root)
        attempt = {"noise": noise, "episode_mb": sizes, "chosen": best}
        attempts.append(attempt)
        if best is None:
            calibration = attempt
            continue
        source = work / "original"
        clean = record(source, DATASET, LENGTHS, 1, noise, limit_mb=best[1])
        per_camera = layout(clean)
        attempt["recorded_layout"] = {camera: [list(key) for key in files] for camera, files in per_camera.items()}
        calibration = attempt
        if layout_ok(per_camera):
            break
        for path in sorted(source.rglob("*"), reverse=True):
            path.unlink() if path.is_file() else path.rmdir()
        source.rmdir()
    require(calibration and calibration.get("chosen") and (work / "original").exists(),
            f"no calibrated limit gave the two-camera layout: {json.dumps(attempts, default=str)}")
    noise = tuple(calibration["noise"])
    targets = {camera: plant_targets(files) for camera, files in per_camera.items()}
    broken, planted = plant(clean, targets, per_camera)
    pq.write_table(broken, source / EPISODES)

    before = inventory(source)
    preflight = run("local_preflight.py", source)
    require(preflight.returncode == 0, preflight.stderr.decode())
    initial = json.loads(preflight.stdout)
    require(initial["status"] == "rollover_candidate", f"preflight returned {initial['status']}")
    expected_edits = sorted((camera, episode) for camera, value in planted.items() for episode in value["episodes"])
    plan_edits = sorted((edit["camera"], edit["episode_index"]) for edit in initial["plan"]["edits"])
    require(plan_edits == expected_edits, f"plan edits {plan_edits} differ from planted {expected_edits}")

    candidate = work / "candidate.json"
    prepared = run("local_repair.py", "plan", source)
    candidate.write_bytes(prepared.stdout)
    read_json(prepared)
    repaired = work / "repaired"
    receipt = read_json(run("local_repair.py", "copy", source, candidate, repaired))
    require(receipt["status"] == "aligned", "repair copy did not align")
    after = inventory(repaired)
    require([name for name in before if before[name] != after.get(name)] == [EPISODES.as_posix()]
            and after.keys() == before.keys(), "repair changed files outside the episode Parquet")
    require(pq.ParquetFile(repaired / EPISODES).read().equals(clean, check_metadata=True),
            "the repaired table differs from the recorded clean table")

    control = work / "control"
    record(control, CONTROL, CONTROL_LENGTHS, sum(LENGTHS) + 1, noise)
    control_before = inventory(control)
    merged = {}
    for arm, root in (("original_then_control", source), ("repaired_then_control", repaired)):
        out = work / arm
        merge_id = f"synthetic/{arm}"
        merge = subprocess.run([sys.executable, "-B", "-m", "lerobot.scripts.lerobot_edit_dataset",
                                "--new_repo_id", merge_id, "--new_root", str(out),
                                "--operation.type", "merge", "--push_to_hub", "false",
                                "--operation.repo_ids", json.dumps([DATASET, CONTROL]),
                                "--operation.roots", json.dumps([str(root), str(control)])],
                               check=False, capture_output=True)
        require(merge.returncode == 0, f"{arm} merge failed: {merge.stderr.decode()[-2000:]}")
        post = run("local_preflight.py", out)
        merged[arm] = {"root": out, "id": merge_id,
                       "video_files": {camera: len(list((out / "videos" / camera).rglob("*.mp4"))) for camera in CAMERAS},
                       "preflight_rc": post.returncode,
                       "preflight": json.loads(post.stdout) if post.stdout else post.stderr.decode()}

    labels = boundary_rows(per_camera, planted)
    merged_labels = {**{row: list(value) for row, value in labels.items()}}
    merged_labels.setdefault(sum(LENGTHS) - 1, []).append("before control join")
    merged_labels.setdefault(sum(LENGTHS), []).append("after control join")
    merged_labels.setdefault(sum(LENGTHS) + sum(CONTROL_LENGTHS) - 1, []).append("last merged row")
    bad = planted_rows(planted)

    reads = {}
    for backend in BACKENDS:
        reads[backend] = {
            "original": scan(source, DATASET, backend, LENGTHS, 1, labels),
            "repaired": scan(repaired, DATASET, backend, LENGTHS, 1, labels),
            "control": scan(control, CONTROL, backend, CONTROL_LENGTHS, sum(LENGTHS) + 1, {}),
            **{arm: scan(value["root"], value["id"], backend, (*LENGTHS, *CONTROL_LENGTHS), 1, merged_labels)
               for arm, value in merged.items()},
        }
        for arm in ("repaired", "control", "repaired_then_control"):
            result = reads[backend][arm]
            require(not result["failures"] and result["item"]["wrong_frame"] == result["item"]["decoder_error"] == 0,
                    f"{backend}: {arm} has a wrong or failed frame")
        for arm in ("original", "original_then_control"):
            stray = [f for f in reads[backend][arm]["failures"] if f["row"] not in bad[f["camera"]]]
            require(not stray, f"{backend}: {arm} failed outside the planted rows: {stray}")

    require(inventory(source) == before and inventory(repaired) == after and inventory(control) == control_before,
            "a merge or read changed an input archive")
    return {
        "versions": {name: version(name) for name in ("lerobot", "av", "torch", "torchcodec", "pyarrow")},
        "ffmpeg": av.ffmpeg_version_info,
        "fps": FPS, "episode_lengths": LENGTHS, "control_lengths": CONTROL_LENGTHS,
        "calibration_attempts": len(attempts),
        "calibration": {**calibration, "chosen": {"margin": calibration["chosen"][0],
                                                  "video_files_size_in_mb": calibration["chosen"][1]}},
        "planted": planted,
        "planted_rows": {camera: [rows[0], rows[-1], len(rows)] for camera, rows in bad.items()},
        "preflight_original": {"status": initial["status"], "edits": len(initial["plan"]["edits"])},
        "copy_receipt": receipt,
        "merges": {arm: {k: v for k, v in value.items() if k not in ("root", "id")} for arm, value in merged.items()},
        "reads": reads,
        "inputs_unchanged": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new local output directory")
    args = parser.parse_args()
    require(version("lerobot") == "0.7.0" and av.__version__ == "15.1.0", "use LeRobot 0.7.0 and PyAV 15.1.0")
    require(version("torchcodec") == "0.17.0+cpu", "use the pinned CPU TorchCodec wheel")
    torch.set_num_threads(2)
    args.output.mkdir()
    result = check(args.output.resolve())
    text = json.dumps(result, indent=2, allow_nan=False, default=str) + "\n"
    (args.output / "result.json").write_text(text)
    print(json.dumps({"check": "multicam", "ok": True}))


if __name__ == "__main__":
    main()
