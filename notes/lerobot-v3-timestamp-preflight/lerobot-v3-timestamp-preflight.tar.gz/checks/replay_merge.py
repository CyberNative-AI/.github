"""Check frame identity after a default LeRobot merge of a repaired rollover."""

import argparse
from collections import Counter
from importlib.metadata import version
import json
from pathlib import Path
import sys

import av  # Load PyAV's FFmpeg before LeRobot can import TorchCodec.
import numpy as np
import torch
from lerobot.configs.video import RGBEncoderConfig
from lerobot.datasets.dataset_tools import merge_datasets
from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lerobot.datasets.video_utils import FrameTimestampError
from lerobot.utils.constants import DEFAULT_FEATURES

from replay import CAMERA, DATASET, FPS, LENGTHS, frame_image, inventory, read_serial, replay, require


CONTROL_LENGTH = 14
FIXTURE_LENGTH = sum(LENGTHS)
BACKENDS = ("pyav", "torchcodec")


def reader(root, dataset_id, backend="pyav"):
    return LeRobotDataset(dataset_id, root=root, video_backend=backend, return_uint8=True, token=False)


def write_control(root, features):
    control = LeRobotDataset.create(
        "synthetic/control", FPS, features, root=root,
        rgb_encoder=RGBEncoderConfig(vcodec="h264"), encoder_threads=1, video_backend="pyav",
    )
    for serial in range(FIXTURE_LENGTH + 1, FIXTURE_LENGTH + CONTROL_LENGTH + 1):
        control.add_frame({
            CAMERA: frame_image(serial),
            "task": "read the frame serial",
            "observation.state": np.array([serial], dtype=np.float32),
            "action": np.zeros(1, dtype=np.float32),
        })
    control.save_episode(parallel_encoding=False)
    control.finalize()


def scan(dataset, first_serial, episode_lengths):
    require(len(dataset) == sum(episode_lengths), "unexpected row count")
    counts = Counter(matched=0, wrong_frame=0, decoder_error=0)
    failures = []
    boundaries = []
    row = 0
    for episode, length in enumerate(episode_lengths):
        for frame in range(length):
            expected = first_serial + row
            item_report = {"row": row, "expected_serial": expected}
            try:
                item = dataset[row]
            except (FrameTimestampError, IndexError) as error:
                item_report["error"] = type(error).__name__
                counts["decoder_error"] += 1
                failures.append(item_report)
            else:
                require((int(item["index"]), int(item["episode_index"]), int(item["frame_index"]))
                        == (row, episode, frame), f"unexpected tabular row identity at {row}")
                require(float(item["observation.state"].reshape(-1)[0]) == expected,
                        f"unexpected tabular serial at {row}")
                actual = read_serial(item[CAMERA])
                item_report["decoded_serial"] = actual
                if actual == expected:
                    counts["matched"] += 1
                else:
                    counts["wrong_frame"] += 1
                    failures.append(item_report)
            if frame in (0, length - 1):
                boundaries.append(item_report)
            row += 1
    return {**counts, "failures": failures, "boundaries": boundaries}


def check_merges(output):
    fixture = output / "fixture"
    fixture.mkdir()
    replay(fixture)

    original = fixture / "original"
    repaired = fixture / "repaired"
    features = {
        key: value for key, value in reader(repaired, DATASET).features.items() if key not in DEFAULT_FEATURES
    }
    control = output / "control"
    write_control(control, features)
    input_roots = (original, repaired, control)
    before = {root: inventory(root) for root in input_roots}
    control_id = "synthetic/control"
    report = {"python": sys.version.split()[0], "packages": {
        name: version(name) for name in ("lerobot", "av", "torch", "torchcodec")
    }, "fps": FPS, "ffmpeg": av.ffmpeg_version_info, "input_episode_lengths": LENGTHS,
        "control_episode_length": CONTROL_LENGTH, "merge_episode_lengths": (*LENGTHS, CONTROL_LENGTH),
        "outputs": {}}
    for label, root in (("original_then_control", original), ("repaired_then_control", repaired)):
        merged = output / label
        merged_id = f"synthetic/{label}"
        merge_datasets([reader(root, DATASET), reader(control, control_id)], merged_id, merged)
        report["outputs"][label] = {
            "video_files": len(list((merged / "videos").rglob("*.mp4"))),
            "reads": {
                backend: scan(reader(merged, merged_id, backend), 1, (*LENGTHS, CONTROL_LENGTH))
                for backend in BACKENDS
            },
        }
    report["clean_control_reads"] = {
        backend: scan(reader(control, control_id, backend), FIXTURE_LENGTH + 1, (CONTROL_LENGTH,))
        for backend in BACKENDS
    }
    require(all(result["matched"] == CONTROL_LENGTH for result in report["clean_control_reads"].values()),
            "an independent clean control failed")
    require({root: inventory(root) for root in input_roots} == before, "a merge mutated its inputs")
    report["input_inventories_unchanged"] = True
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new local output directory")
    args = parser.parse_args()
    require(version("lerobot") == "0.7.0" and av.__version__ == "15.1.0",
            "use LeRobot 0.7.0 and PyAV 15.1.0")
    require(version("torchcodec") == "0.17.0+cpu", "use the pinned CPU TorchCodec wheel")
    torch.set_num_threads(2)
    args.output.mkdir()
    result = check_merges(args.output.resolve())
    (args.output / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
