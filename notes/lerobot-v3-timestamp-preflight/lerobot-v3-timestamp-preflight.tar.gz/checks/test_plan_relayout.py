import unittest

from plan_relayout import Refused, camera_relayout

FPS = 10


def grid(n):
    return [i / FPS for i in range(n)], [1 / FPS] * n


def files(*counts):
    return [((0, i), *grid(n)) for i, n in enumerate(counts)]


def eps(spec):
    """spec: list of (length, file, from_s)."""
    return [{"episode_index": i, "length": n, "file": (0, f), "from": s, "to": s + n / FPS}
            for i, (n, f, s) in enumerate(spec)]


def ts(spec):
    return {i: [k / FPS for k in range(n)] for i, (n, _, _) in enumerate(spec)}


class Relayout(unittest.TestCase):
    def run_spec(self, counts, spec):
        return camera_relayout("cam", files(*counts), eps(spec), ts(spec), FPS)

    def test_correct_layout_has_no_edits(self):
        self.assertEqual(self.run_spec([30, 20], [(10, 0, 0.0), (20, 0, 1.0), (20, 1, 0.0)]), [])

    def test_bug1_wrong_file_only(self):
        # episodes 1-2 are the tail of file 0 but point at file 1 (their source ended in file 1)
        edits = self.run_spec([30, 20], [(10, 0, 0.0), (10, 1, 1.0), (10, 1, 2.0), (20, 1, 0.0)])
        self.assertEqual([(e["episode_index"], e["old_file"], e["new_file"]) for e in edits],
                         [(1, [0, 1], [0, 0]), (2, [0, 1], [0, 0])])
        self.assertTrue(all(abs(e["new_from"] - e["old_from"]) < 1e-9 for e in edits))

    def test_bug2_offset_only(self):
        edits = self.run_spec([20, 20], [(20, 0, 0.0), (10, 1, 0.0), (10, 1, 3.0)])
        self.assertEqual([(e["episode_index"], e["old_from"], e["new_from"]) for e in edits], [(2, 3.0, 1.0)])

    def test_bug1_then_bug2_offset(self):
        # reporter shape: 1-2 misfiled; the next source in file 1 carries their 2 s as an offset
        edits = self.run_spec([30, 30], [(10, 0, 0.0), (10, 1, 1.0), (10, 1, 2.0), (10, 1, 0.0), (20, 1, 3.0)])
        got = {e["episode_index"]: (e["new_file"], round(e["new_from"], 6)) for e in edits}
        self.assertEqual(got, {1: ([0, 0], 1.0), 2: ([0, 0], 2.0), 4: ([0, 1], 1.0)})

    def test_refusals(self):
        cases = {
            "leftover samples": ([31, 20], [(10, 0, 0.0), (20, 0, 1.0), (20, 1, 0.0)]),
            "crosses file end": ([25, 25], [(10, 0, 0.0), (20, 0, 1.0), (20, 1, 0.0)]),
            "too many frames": ([10], [(10, 0, 0.0), (10, 0, 1.0)]),
        }
        for name, (counts, spec) in cases.items():
            with self.subTest(name), self.assertRaises(Refused):
                self.run_spec(counts, spec)

    def test_changes_the_known_faults_cannot_make_are_refused(self):
        cases = {
            # stored file earlier than packed: episode 2 sits in file 1 but points at file 0
            "earlier file": ([20, 20], [(10, 0, 0.0), (10, 0, 1.0), (20, 0, 0.0)]),
            # negative offset: episode 2 stored 1 s before its packed start
            "negative offset": ([10, 30], [(10, 0, 0.0), (10, 1, 0.0), (20, 1, 0.0)]),
        }
        for name, (counts, spec) in cases.items():
            with self.subTest(name), self.assertRaises(Refused):
                self.run_spec(counts, spec)
        spec = [(10, 0, 0.0), (10, 1, 1.0), (10, 1, 0.0)]
        e = eps(spec)
        e[1]["to"] += 0.5  # duration no longer matches the length
        with self.assertRaises(Refused):
            camera_relayout("cam", files(20, 10), e, ts(spec), FPS)

    def test_merge_offset_with_wrong_file(self):
        # LeRobot 0.4.2's merge: episode 3's source was appended to file 1 with the duration of file 0 (2 s) as its
        # offset and then continued into file 2; episode 1's source likewise ended in file 1
        edits = self.run_spec([20, 20, 20], [(10, 0, 0.0), (10, 1, 1.0), (10, 1, 0.0), (10, 2, 3.0), (20, 2, 0.0)])
        got = {e["episode_index"]: (e["old_file"], e["new_file"], e["old_from"], e["new_from"]) for e in edits}
        self.assertEqual(got, {1: ([0, 1], [0, 0], 1.0, 1.0), 3: ([0, 2], [0, 1], 3.0, 1.0)})

    def test_unrelated_offset_beside_a_wrong_file_refused(self):
        # episode 1 names the next file (bug 1) and episode 3 carries its 0.25 s; that alone is accepted
        fps, counts = 8, (5, 6)
        f = [((0, i), [k / fps for k in range(n)], [1 / fps] * n) for i, n in enumerate(counts)]
        spec = [(3, 0, 0.0), (2, 1, 3 / fps), (4, 1, 0.0), (2, 1, 6 / fps)]

        def run(first_start):
            e = [{"episode_index": i, "length": n, "file": (0, k), "from": s, "to": s + n / fps}
                 for i, (n, k, s) in enumerate(spec)]
            e[0]["from"], e[0]["to"] = first_start, first_start + 3 / fps
            t = {i: [k / fps for k in range(n)] for i, (n, _, _) in enumerate(spec)}
            return camera_relayout("cam", f, e, t, fps)

        self.assertEqual([(e["episode_index"], e["new_file"], e["new_from"]) for e in run(0.0)],
                         [(1, [0, 0], 3 / fps), (3, [0, 1], 4 / fps)])
        # an unrelated half-frame offset on episode 0, in its unchanged first file, must not enter a plan
        with self.assertRaisesRegex(Refused, "first episode in file"):
            run(0.5 / fps)

    def test_offset_needs_evidence(self):
        cases = {
            # the first episode packed in a file carries an offset (even one equal to the earlier files' 2 s)
            "first episode in file": ([20, 20], [(20, 0, 0.0), (10, 1, 2.0), (10, 1, 3.0)], "first episode in file"),
            # 1.5 s is neither file 0's 2 s nor a misfiled tail (there is none)
            "unexplained value": ([20, 20], [(20, 0, 0.0), (10, 1, 0.0), (10, 1, 2.5)], "matches no offset"),
            # file 0 has no earlier file and no previous tail
            "offset in the first file": ([30], [(10, 0, 0.0), (10, 0, 1.5), (10, 0, 2.5)], r"\(none\)"),
            # the offset changes between episodes of one file
            "offset changes": ([20, 30], [(20, 0, 0.0), (10, 1, 0.0), (10, 1, 3.0), (10, 1, 5.0)], "differs from"),
            # the offset stops before the end of the file
            "offset stops": ([20, 30], [(20, 0, 0.0), (10, 1, 0.0), (10, 1, 3.0), (10, 1, 2.0)], "stops here"),
        }
        for name, (counts, spec, reason) in cases.items():
            with self.subTest(name), self.assertRaisesRegex(Refused, reason):
                self.run_spec(counts, spec)

    def test_file_evidence(self):
        cases = {
            # episode 1 names file 1, but the first episode packed in file 1 names file 2
            "no continuation": ([20, 10, 10], [(10, 0, 0.0), (10, 1, 1.0), (10, 2, 0.0), (10, 2, 0.0)],
                                "no source continued"),
            # stored files go back from file 1 to file 0
            "back to an earlier file": ([20, 20], [(10, 1, 0.0), (10, 0, 1.0), (20, 1, 0.0)], "go back"),
        }
        for name, (counts, spec, reason) in cases.items():
            with self.subTest(name), self.assertRaisesRegex(Refused, reason):
                self.run_spec(counts, spec)

    def test_irregular_grid_refused(self):
        f = files(20)
        f[0][1][5] += 0.01
        with self.assertRaises(Refused):
            camera_relayout("cam", f, eps([(20, 0, 0.0)]), ts([(20, 0, 0.0)]), FPS)

    def test_indices_and_rows_checked(self):
        spec = [(10, 0, 0.0), (10, 0, 1.0)]
        e = eps(spec)
        e[1]["episode_index"] = 5
        with self.assertRaises(Refused):
            camera_relayout("cam", files(20), e, {0: ts(spec)[0], 5: ts(spec)[1]}, FPS)
        t = ts(spec)
        t[1] = t[1][:-1]
        with self.assertRaises(Refused):
            camera_relayout("cam", files(20), eps(spec), t, FPS)
        t = ts(spec)
        t[1][3] += 0.05  # a row timestamp off the grid
        with self.assertRaises(Refused):
            camera_relayout("cam", files(20), eps(spec), t, FPS)


if __name__ == "__main__":
    unittest.main()
