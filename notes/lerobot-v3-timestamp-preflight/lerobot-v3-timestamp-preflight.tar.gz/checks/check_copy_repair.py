"""Replay the local repair commands and read the copy through LeRobot."""

import argparse
from importlib.metadata import version
import json
from pathlib import Path
import shutil
import subprocess
import sys

import pyarrow.parquet as pq
import torch

from replay import (
    DATASET,
    EPISODES,
    LENGTHS,
    generate,
    inventory,
    require,
)  # loads PyAV first
from replay_merge import BACKENDS, CONTROL_LENGTH, reader, scan, write_control
from lerobot.utils.constants import DEFAULT_FEATURES


KIT = Path(__file__).resolve().parents[1]
GUARD = Path(__file__).resolve().with_name("guard.py")


def run(script, *args):
    return subprocess.run(
        [sys.executable, "-B", str(GUARD), str(KIT / script), *map(str, args)],
        capture_output=True,
        check=False,
    )


def read(result):
    require(result.returncode == 0 and not result.stderr, result.stderr.decode())
    return json.loads(result.stdout)


def refused(result, reason):
    require(
        result.returncode == 2
        and not result.stdout
        and reason in result.stderr.decode(),
        (result.returncode, result.stdout, result.stderr),
    )
    return result.stderr.decode().strip().removeprefix("Refused: ")


def check(work):
    tool = "local_repair.py"
    source = work / "original"
    scratch = work / "generation"
    scratch.mkdir()
    clean = generate(source, scratch)
    before = inventory(source)
    prepared = run(tool, "plan", source)
    saved = read(prepared)
    require(
        prepared.stdout == run(tool, "plan", source).stdout, "plan did not reproduce"
    )
    require(saved["source_files"] == before, "plan lacks the exact source inventory")
    initial = read(run("local_preflight.py", source))
    require(saved["plan"] == initial["plan"], "plan differs from standalone preflight")
    plan_path = work / "candidate.json"
    plan_path.write_bytes(prepared.stdout)

    repaired = work / "repaired"
    applied = run(tool, "copy", source, plan_path, repaired)
    receipt = read(applied)
    duplicate = run(tool, "copy", source, plan_path, work / "second-copy")
    read(duplicate)
    require(applied.stdout == duplicate.stdout, "receipt did not reproduce")
    require(
        inventory(repaired) == inventory(work / "second-copy"), "copy did not reproduce"
    )
    after = inventory(repaired)
    require(after.keys() == before.keys(), "copy inventory differs")
    require(
        [name for name in before if before[name] != after[name]]
        == [EPISODES.as_posix()],
        "copy changed files outside the episode Parquet",
    )
    require(
        pq.ParquetFile(repaired / EPISODES).read().equals(clean, check_metadata=True),
        "the repaired table differs from the original clean table",
    )
    require(
        read(run("local_preflight.py", repaired)) == receipt["preflight"]
        and receipt["preflight"]["status"] == "aligned",
        "standalone preflight did not align",
    )
    refusals = {
        "existing_destination": refused(
            run(tool, "copy", source, plan_path, repaired), "output already exists"
        ),
        "destination_inside_source": refused(
            run(tool, "copy", source, plan_path, source / "inside"),
            "output must be outside",
        ),
        "aligned_archive": refused(
            run(tool, "plan", repaired), "preflight returned aligned"
        ),
    }
    saved["plan"]["edits"][0]["new_from"] = 0.75
    wrong_plan = work / "wrong.json"
    wrong_plan.write_text(json.dumps(saved), encoding="utf-8")
    unused = work / "unused"
    refusals["wrong_edit"] = refused(
        run(tool, "copy", source, wrong_plan, unused), "saved plan differs"
    )
    altered = work / "altered"
    shutil.copytree(source, altered)
    video = next(altered.glob("videos/**/*.mp4"))
    data = video.read_bytes()
    video.write_bytes(data[:-1] + bytes([data[-1] ^ 1]))
    altered_files = inventory(altered)
    refusals["changed_video_same_length"] = refused(
        run(tool, "copy", altered, plan_path, unused),
        "source inventory or bytes differ",
    )
    require(inventory(altered) == altered_files, "refusal changed the altered source")
    (altered / EPISODES).with_name("file-001.parquet").write_bytes(
        (altered / EPISODES).read_bytes()
    )
    refusals["multiple_episode_shards"] = refused(
        run(tool, "plan", altered), "one episode Parquet shard"
    )

    features = {
        key: value
        for key, value in reader(repaired, DATASET).features.items()
        if key not in DEFAULT_FEATURES
    }
    control = work / "control"
    write_control(control, features)
    merged = work / "merged"
    merged_id = "synthetic/local-repair-merge"
    subprocess.run(
        [
            sys.executable,
            "-B",
            "-m",
            "lerobot.scripts.lerobot_edit_dataset",
            "--new_repo_id",
            merged_id,
            "--new_root",
            str(merged),
            "--operation.type",
            "merge",
            "--operation.repo_ids",
            json.dumps([DATASET, "synthetic/control"]),
            "--operation.roots",
            json.dumps([str(repaired), str(control)]),
            "--push_to_hub",
            "false",
        ],
        check=True,
    )
    merged_preflight = read(run("local_preflight.py", merged))
    require(merged_preflight["status"] == "aligned", "merge no longer aligns")
    matches = {}
    for backend in BACKENDS:
        copy_result = scan(reader(repaired, DATASET, backend), 1, LENGTHS)
        merge_result = scan(
            reader(merged, merged_id, backend), 1, (*LENGTHS, CONTROL_LENGTH)
        )
        require(
            copy_result["matched"] == sum(LENGTHS) and not copy_result["failures"],
            f"{backend} selected a wrong frame in the repaired copy",
        )
        require(
            merge_result["matched"] == sum(LENGTHS) + CONTROL_LENGTH
            and not merge_result["failures"],
            f"{backend} selected a wrong frame after merging",
        )
        matches[backend] = {"copy": copy_result, "merge": merge_result}

    require(
        inventory(source) == before and inventory(repaired) == after,
        "archive bytes changed",
    )
    require(
        not unused.exists() and not list(work.glob(".lerobot-repair-*")),
        "refused work was published or retained",
    )
    return {
        "versions": {
            name: version(name) for name in ("lerobot", "pyarrow", "av", "torchcodec")
        },
        "copy_receipt": receipt,
        "source_files_verified": len(before),
        "refusals": refusals,
        "post_merge_preflight": merged_preflight,
        "reads": matches,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir()
    torch.set_num_threads(2)
    result = check(args.output.resolve())
    (args.output / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
