"""Run a kit script under an audit hook that raises an error on the listed audit events.

usage: python -B guard.py SCRIPT [ARGS...]

BLOCKED lists event-name prefixes for network and process-creation events that
Python raises. The hook sees only calls that raise these events: native code that
opens a connection or starts a process without them is outside what it can observe.
"""

import os
import runpy
import sys

BLOCKED = (
    "socket.",
    "subprocess.Popen",
    "os.system",
    "os.exec",
    "os.fork",
    "os.forkpty",
    "os.posix_spawn",
    "os.spawn",
    "os.startfile",
    "urllib.Request",
    "http.client.connect",
    "ftplib.connect",
    "smtplib.connect",
    "webbrowser.open",
)


def hook(event, args):
    if event.startswith(BLOCKED):
        raise RuntimeError(f"guard blocked {event}")


def main():
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    script = os.path.abspath(sys.argv[1])
    sys.argv = [script, *sys.argv[2:]]
    sys.path.insert(0, os.path.dirname(script))
    sys.addaudithook(hook)
    runpy.run_path(script, run_name="__main__")


if __name__ == "__main__":
    main()
