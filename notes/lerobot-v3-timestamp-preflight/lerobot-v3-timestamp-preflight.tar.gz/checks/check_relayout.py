"""Two cameras with episodes pointing at the wrong video file: plan a relayout, repair a copy, read every frame.

LeRobot 0.7.0's own recorder writes the two-camera fixture of check_multicam.py (same calibration). Per
camera, the shape LeRobot 0.4.0-0.4.2 merges leave (#2550) is planted at that camera's first file change
where both files hold at least two episodes: the earlier file's last episode points at the next file with its
times unchanged (bug 1), and the next file's later episodes carry that episode's duration as an offset
(bug 2). The unchanged kit must return relayout_candidate with exactly the planted episodes, write a copy whose
episode table equals the recorded clean one, and read every row of the copy with the right frame on PyAV and
TorchCodec. The broken archive may fail or show wrong frames only on planted rows. Five copies of the broken
archive must be refused (needs_review with relayout_refused, and no plan): one adds an unrelated half-frame
offset to episode 0 of the first camera in its unchanged first file; the others add an MP4 that the relayout
cannot account for: in a chunk folder of a camera that info.json does not declare, directly in that camera's
folder, one folder deeper in a declared camera's chunk folder, or with an upper-case .MP4 name in a declared
camera's chunk folder. The repaired copy with that MP4 directly in the undeclared camera's folder must be
refused too.
"""

import argparse
from importlib.metadata import version
import json
from pathlib import Path
import shutil

import av  # Load PyAV's FFmpeg before LeRobot can import TorchCodec.
import pyarrow as pa
import pyarrow.parquet as pq
import torch

from check_multicam import (BACKENDS, CAMERAS, EPISODES, FPS, LENGTHS, NOISE_PAIRS, choose_limit, groups,
                            layout, layout_ok, read_json, record, run, scan)
from replay import inventory, require

DATASET = "synthetic/two-camera-relayout"


def targets(files):
    """The first file change where both files hold at least two episodes: (misfiled, offset) episodes."""
    g = groups(files)
    for (key, before), (_, after) in zip(g, g[1:]):
        if len(before) >= 2 and len(after) >= 2:
            return [before[-1]], after[1:]
    return None


def relayout_ok(per_camera):
    t = {camera: targets(files) for camera, files in per_camera.items()}
    return all(t.values()) and t[CAMERAS[0]][0] != t[CAMERAS[1]][0]


def plant(clean, per_camera):
    broken, planted = clean, {}
    for camera in CAMERAS:
        misfiled, offset = targets(per_camera[camera])
        next_file = per_camera[camera][offset[0]]
        carry = sum(LENGTHS[e] for e in misfiled) / FPS
        columns = {f"videos/{camera}/{name}": broken[f"videos/{camera}/{name}"].to_pylist()
                   for name in ("chunk_index", "file_index", "from_timestamp", "to_timestamp")}
        for e in misfiled:
            columns[f"videos/{camera}/chunk_index"][e], columns[f"videos/{camera}/file_index"][e] = next_file
        for e in offset:
            columns[f"videos/{camera}/from_timestamp"][e] += carry
            columns[f"videos/{camera}/to_timestamp"][e] += carry
        for name, values in columns.items():
            index = broken.schema.get_field_index(name)
            field = broken.schema.field(index)
            broken = broken.set_column(index, field, pa.array(values, type=field.type))
        planted[camera] = {"misfiled": misfiled, "offset": offset, "carry_s": carry, "next_file": list(next_file)}
    return broken, planted


def unrelated_offset(root, planted):
    """Half a frame on episode 0 of the first camera, which stays in its first file with its times unchanged."""
    camera = CAMERAS[0]
    require(0 not in planted[camera]["misfiled"] + planted[camera]["offset"], "episode 0 is planted")
    table = pq.ParquetFile(root / EPISODES).read()
    require(table[f"videos/{camera}/file_index"][0].as_py() == 0, "episode 0 is not in the first file")
    for name in ("from_timestamp", "to_timestamp"):
        index = table.schema.get_field_index(f"videos/{camera}/{name}")
        field = table.schema.field(index)
        values = table.column(index).to_pylist()
        values[0] += 0.5 / FPS
        table = table.set_column(index, field, pa.array(values, type=field.type))
    pq.write_table(table, root / EPISODES)
    return f"{camera}, episode 0: stored start and end moved by {0.5 / FPS} s"


def extra_mp4(*parts):
    """A change that adds a copy of the first camera's first stored MP4 at videos/<parts>."""
    def change(root, planted):
        first = sorted((root / "videos" / CAMERAS[0]).glob("*/*.mp4"))[0]
        extra = root.joinpath("videos", *(part.format(chunk=first.parent.name, file=first.name) for part in parts))
        require(not extra.exists(), f"{extra} exists")
        extra.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(first, extra)
        return f"added {extra.relative_to(root).as_posix()}"
    return change


UNDECLARED = "observation.images.undeclared"
undeclared_camera = extra_mp4(UNDECLARED, "{chunk}", "{file}")
undeclared_camera_direct = extra_mp4(UNDECLARED, "{file}")
declared_camera_nested = extra_mp4(CAMERAS[0], "{chunk}", "extra", "{file}")
declared_camera_upper_case = extra_mp4(CAMERAS[0], "{chunk}", "file-099.MP4")


def refusal(work, source, planted, name, change, reason):
    copy = work / f"refused-{name}"
    shutil.copytree(source, copy)
    detail = change(copy, planted)
    before = inventory(copy)
    preflight = run("local_preflight.py", copy)
    require(preflight.stdout, f"{name}: preflight wrote no report (exit {preflight.returncode})")
    report = json.loads(preflight.stdout)
    refused = [issue["detail"] for issue in report["issues"] if issue["code"] == "relayout_refused"]
    require(report["status"] == "needs_review" and preflight.returncode == 2,
            f"{name}: preflight returned {report['status']} (exit {preflight.returncode})")
    require(len(refused) == 1 and reason in refused[0], f"{name}: relayout not refused for its reason: {refused}")
    plan = run("local_repair.py", "plan", copy)
    require(plan.returncode == 2 and not plan.stdout and plan.stderr.startswith(b"Refused: preflight returned "
                                                                                   b"needs_review"),
            f"{name}: plan did not refuse (exit {plan.returncode})")
    require(inventory(copy) == before, f"{name}: a refused run changed the copy")
    return {"change": detail, "status": report["status"], "exit": preflight.returncode,
            "relayout_refused": refused[0], "plan_exit": plan.returncode}


def check(work):
    per_camera, chosen = None, None
    for noise in NOISE_PAIRS:
        calibration_root = work / f"calibration-{noise[0]}-{noise[1]}"
        record(calibration_root, "synthetic/calibration", LENGTHS, 1, noise, limit_mb=1e-6)
        _, best = choose_limit(calibration_root)
        if best is None:
            continue
        source = work / f"original-{noise[0]}-{noise[1]}"
        clean = record(source, DATASET, LENGTHS, 1, noise, limit_mb=best[1])
        per_camera = layout(clean)
        if layout_ok(per_camera) and relayout_ok(per_camera):
            chosen = {"noise": list(noise), "video_files_size_in_mb": best[1]}
            break
    require(chosen is not None, "no calibrated limit gave a two-camera layout for the relayout check")
    broken, planted = plant(clean, per_camera)
    pq.write_table(broken, source / EPISODES)
    before = inventory(source)

    preflight = run("local_preflight.py", source)
    require(preflight.stdout, f"preflight wrote no report (exit {preflight.returncode}): {preflight.stderr.decode()}")
    initial = json.loads(preflight.stdout)
    require(initial["status"] == "relayout_candidate" and preflight.returncode == 0,
            f"preflight returned {initial['status']} (exit {preflight.returncode})")
    expected = sorted((camera, e) for camera, p in planted.items() for e in p["misfiled"] + p["offset"])
    got = sorted((edit["camera"], edit["episode_index"]) for edit in initial["plan"]["edits"])
    require(got == expected, f"plan edits {got} differ from planted {expected}")

    candidate = work / "candidate.json"
    prepared = run("local_repair.py", "plan", source)
    candidate.write_bytes(prepared.stdout)
    read_json(prepared)
    repaired = work / "repaired"
    receipt = read_json(run("local_repair.py", "copy", source, candidate, repaired))
    require(receipt["status"] == "aligned", "repair copy did not align")
    after = inventory(repaired)
    require([name for name in before if before[name] != after.get(name)] == [EPISODES.as_posix()]
            and after.keys() == before.keys(), "repair changed files outside the episode Parquet")
    require(pq.ParquetFile(repaired / EPISODES).read().equals(clean, check_metadata=True),
            "the repaired table differs from the recorded clean table")

    starts = [sum(LENGTHS[:e]) for e in range(len(LENGTHS))]
    bad = {camera: sorted(r for e in p["misfiled"] + p["offset"] for r in range(starts[e], starts[e] + LENGTHS[e]))
           for camera, p in planted.items()}
    reads = {}
    for backend in BACKENDS:
        reads[backend] = {"original": scan(source, DATASET, backend, LENGTHS, 1, {}),
                          "repaired": scan(repaired, DATASET, backend, LENGTHS, 1, {})}
        r = reads[backend]["repaired"]
        require(not r["failures"] and r["item"]["wrong_frame"] == r["item"]["decoder_error"] == 0,
                f"{backend}: the repaired copy has a wrong or failed frame")
        o = reads[backend]["original"]
        stray = [f for f in o["failures"] if f["row"] not in bad[f["camera"]]]
        require(not stray, f"{backend}: the broken archive failed outside the planted rows: {stray}")
        require(o["failures"], f"{backend}: the planted shape changed no read")
    refusals = {name: refusal(work, base, planted, name, change, reason) for name, base, change, reason in (
        ("unrelated_offset", source, unrelated_offset, "the first episode in file"),
        ("undeclared_camera", source, undeclared_camera, "outside the declared cameras"),
        ("undeclared_camera_direct", source, undeclared_camera_direct, "outside the declared cameras"),
        ("declared_camera_nested", source, declared_camera_nested, "outside the declared cameras"),
        ("declared_camera_upper_case", source, declared_camera_upper_case, "unexpected video file name"),
        ("repaired_undeclared_camera_direct", repaired, undeclared_camera_direct, "outside the declared cameras"),
    )}
    require(inventory(source) == before and inventory(repaired) == after, "a read changed an input archive")
    return {
        "versions": {name: version(name) for name in ("lerobot", "av", "torch", "torchcodec", "pyarrow")},
        "ffmpeg": av.ffmpeg_version_info,
        "fps": FPS, "episode_lengths": LENGTHS, "calibration": chosen,
        "recorded_layout": {camera: [list(key) for key in files] for camera, files in per_camera.items()},
        "planted": planted,
        "preflight_original": {"status": initial["status"], "edits": len(initial["plan"]["edits"])},
        "copy_receipt": receipt,
        "refusals": refusals,
        "reads": {b: {arm: {"item": v["item"], "camera": v["camera"], "failures": len(v["failures"])}
                      for arm, v in arms.items()} for b, arms in reads.items()},
        "inputs_unchanged": True,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new local output directory")
    args = parser.parse_args()
    require(version("lerobot") == "0.7.0" and av.__version__ == "15.1.0", "use LeRobot 0.7.0 and PyAV 15.1.0")
    require(version("torchcodec") == "0.17.0+cpu", "use the pinned CPU TorchCodec wheel")
    torch.set_num_threads(2)
    args.output.mkdir()
    result = check(args.output.resolve())
    text = json.dumps(result, indent=2, allow_nan=False, default=str) + "\n"
    (args.output / "result.json").write_text(text)
    print(json.dumps({"check": "relayout", "ok": True}))


if __name__ == "__main__":
    main()
