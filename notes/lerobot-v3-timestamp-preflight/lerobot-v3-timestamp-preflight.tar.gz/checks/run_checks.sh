#!/usr/bin/env bash
# Run every kit check on generated archives and compare the outputs with EXPECTED-OUTPUTS.sha256.
# usage: bash checks/run_checks.sh NEW_OUTPUT_DIRECTORY
# The exit status comes from checks/verify_run.py, which reads the written summary and outputs.
set -euo pipefail
unset CDPATH

if [[ $# -ne 1 ]]; then
  echo "usage: bash checks/run_checks.sh NEW_OUTPUT_DIRECTORY" >&2
  exit 2
fi
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
# Resolve the existing parent and check the new directory's final location before creating anything.
name=$(basename -- "$1")
if [[ -z $1 || $name == . || $name == .. || $name == / ]]; then
  echo "refused: name a new directory" >&2
  exit 2
fi
if ! parent=$(cd -- "$(dirname -- "$1")" 2> /dev/null && pwd -P); then
  echo "refused: the parent directory of $1 must exist" >&2
  exit 2
fi
out=${parent%/}/$name
case $out/ in
  "$kit"/*) echo "refused: the output directory must be outside the kit" >&2; exit 2 ;;
esac
if [[ -e $out || -L $out ]]; then
  echo "refused: $1 already exists" >&2
  exit 2
fi
mkdir -m 700 -- "$out"
mkdir -m 700 -- "$out/tmp" "$out/hf" "$out/cache"

(cd -- "$kit" && sha256sum --strict --check --quiet SHA256SUMS)

unset PYTHONOPTIMIZE PYTHONSTARTUP PYTHONHOME PYTHONINSPECT PYTHONUSERBASE
export PYTHONPATH="$kit:$kit/checks"
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 PYTHONNOUSERSITE=1
export TMPDIR="$out/tmp" XDG_CACHE_HOME="$out/cache"
export TORCHINDUCTOR_CACHE_DIR="$out/cache/torchinductor" TRITON_CACHE_DIR="$out/cache/triton"
export HF_HOME="$out/hf" HF_LEROBOT_HOME="$out/hf/lerobot"
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 HF_HUB_DISABLE_PROGRESS_BARS=1 HF_HUB_DISABLE_TELEMETRY=1
export CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2

summary="$out/summary.jsonl"
: > "$summary"

step() {
  local name=$1
  shift
  local rc=0
  "$@" > "$out/$name.out" 2> "$out/$name.err" || rc=$?
  printf '{"step":"%s","rc":%d}\n' "$name" "$rc" >> "$summary"
  if [[ $rc -ne 0 ]]; then
    echo "FAIL $name (exit $rc); see $out/$name.err" >&2
    exit 1
  fi
  echo "ok $name"
}

cd -- "$kit"
step env python -B checks/check_env.py requirements.txt
step unit python -B -m unittest discover -s checks -p 'test_*.py' -v
step demo python -B checks/replay.py "$out/demo"
step merge python -B checks/replay_merge.py "$out/merge"
step preflight python -B checks/check_preflight.py "$out/demo" "$out/merge"
step copy python -B checks/check_copy_repair.py "$out/copy"
step multicam python -B checks/check_multicam.py "$out/multicam"

python -B checks/verify_run.py "$out" checks/EXPECTED-OUTPUTS.sha256
