"""Check a local LeRobot v3 archive's stored camera queries before a merge."""

import argparse
import json
import os
from bisect import bisect_left
from collections import defaultdict
from math import isfinite
from pathlib import Path
import re
from string import Formatter
from struct import error as StructError

import pyarrow.parquet as pq

from moovpts import Refused as MP4Refused, parse as parse_mp4
from plan_relayout import camera_relayout
from plan_rollover import TOL, Refused, build_plan, near

DATASET = "local"
EPISODE_COLUMNS = (
    "episode_index",
    "length",
    "dataset_from_index",
    "dataset_to_index",
    "data/chunk_index",
    "data/file_index",
)
VIDEO_COLUMNS = ("chunk_index", "file_index", "from_timestamp", "to_timestamp")
DATA_COLUMNS = ("episode_index", "frame_index", "index", "timestamp")
INDEX_FIELDS = ("chunk_index", "file_index")
# An integer field may carry a zero-padded width of at most two digits, as in "{chunk_index:03d}".
INDEX_SPEC = re.compile(r"0?[0-9]{0,2}d?")
VIDEO_FILE = re.compile(r"chunk-([0-9]+)/file-([0-9]+)\.mp4")
# The relayout path runs only when the stored file references disagree with the video files (sample counts or
# an unreferenced MP4), the evidence of episodes pointing at the wrong file. Any other issue (counts in
# info.json, an unreadable or irregular video, a referenced file that is missing) keeps needs_review.
RELAYOUT_ISSUES = {"video_sample_count", "video_inventory_disagrees", "packed_queries_unaligned"}


def view(stream):
    """Return each video sample's presentation time and duration in seconds, in time order."""
    track = parse_mp4(stream)
    scale = track["timescale"]
    order = sorted(range(len(track["pts"])), key=lambda i: track["pts"][i])
    return [track["pts"][i] / scale for i in order], [track["dur"][i] / scale for i in order]


def require(condition, message):
    if not condition:
        raise Refused(message)


def stored_videos(root):
    """Every file or folder below videos/ whose name ends in .mp4 in any letter case, at any depth. Symbolic
    links are followed, as elsewhere in the preflight. A folder reached twice or a listing that fails stops the
    check instead of shortening the list."""
    top = root / "videos"
    if not top.is_dir():
        return set()
    found, seen, pending = set(), set(), [top]
    while pending:
        folder = pending.pop()
        status = folder.stat()
        require(
            (status.st_dev, status.st_ino) not in seen,
            f"folder reached twice below videos/: {folder.relative_to(root)}",
        )
        seen.add((status.st_dev, status.st_ino))
        with os.scandir(folder) as listing:
            entries = sorted(listing, key=lambda entry: entry.name)
        for entry in entries:
            path = folder / entry.name
            if entry.name.lower().endswith(".mp4"):
                found.add(path.relative_to(root))
            if entry.is_dir():
                pending.append(path)
    return found


def finite_number(value):
    """True for a finite int or float. Decimals, Booleans, dates and other types are refused."""
    return type(value) in (int, float) and isfinite(value)


def template_fields(template):
    """Return the replacement fields of a path template, or None if it cannot be parsed."""
    if type(template) is not str:
        return None
    try:
        return [part[1:] for part in Formatter().parse(template) if part[1] is not None]
    except ValueError:
        return None


def file_path(template, directory, key, **fields):
    require(
        all(type(n) is int and n >= 0 for n in key), f"invalid {directory} file indices"
    )
    parts = template_fields(template)
    require(
        parts is not None
        and all(
            conversion is None
            and (
                INDEX_SPEC.fullmatch(spec)
                if name in INDEX_FIELDS
                else name in fields and spec == ""
            )
            for name, spec, conversion in parts
        ),
        f"unsupported {directory} path template in info.json",
    )
    path = Path(template.format(chunk_index=key[0], file_index=key[1], **fields))
    require(
        not path.is_absolute()
        and path.parts[:1] == (directory,)
        and ".." not in path.parts,
        f"invalid {directory} path in info.json",
    )
    return path


def episode_index(root, info, cameras):
    episode_files = sorted((root / "meta/episodes").glob("*/*.parquet"))
    require(episode_files, "missing episode Parquets")
    columns = [
        *EPISODE_COLUMNS,
        *(
            f"videos/{camera}/{column}"
            for camera in cameras
            for column in VIDEO_COLUMNS
        ),
    ]
    episodes = []
    for path in episode_files:
        episodes.extend(pq.ParquetFile(path).read(columns=columns).to_pylist())
    require(
        episodes and all(type(row["episode_index"]) is int for row in episodes),
        "missing or invalid episode indices",
    )
    episodes.sort(key=lambda row: row["episode_index"])
    data_files = defaultdict(list)
    start = 0
    for number, episode in enumerate(episodes):
        length = episode["length"]
        require(
            episode["episode_index"] == number and type(length) is int and length > 0,
            f"expected contiguous episode indices and positive lengths at episode {number}",
        )
        require(
            (episode["dataset_from_index"], episode["dataset_to_index"])
            == (start, start + length),
            f"episode {number}: invalid tabular span",
        )
        key = (episode["data/chunk_index"], episode["data/file_index"])
        path = file_path(info["data_path"], "data", key)
        data_files[path].append(episode)
        start += length
    return episodes, data_files, start


def tabular_timestamps(root, data_files):
    stored = {path.relative_to(root) for path in (root / "data").glob("*/*.parquet")}
    require(
        stored == data_files.keys(),
        "tabular file inventory disagrees with the episode metadata",
    )
    timestamps = {}
    count = 0
    for path, episodes in data_files.items():
        data = pq.ParquetFile(root / path).read(columns=DATA_COLUMNS)
        count += len(data)
        position = 0
        for episode in episodes:
            number, length = episode["episode_index"], episode["length"]
            start = episode["dataset_from_index"]
            rows = data.slice(position, length).to_pylist()
            require(len(rows) == length, f"episode {number}: incomplete tabular rows")
            times = []
            for frame, row in enumerate(rows):
                identity = (row["episode_index"], row["frame_index"], row["index"])
                timestamp = row["timestamp"]
                require(
                    identity == (number, frame, start + frame)
                    and finite_number(timestamp),
                    f"episode {number}: invalid identity or timestamp at frame {frame}",
                )
                times.append(timestamp)
            timestamps[number] = times
            position += length
        require(position == len(data), f"{path}: unaccounted tabular rows")
    return timestamps, count


def query_checks(points, times, start, position, fps):
    packed_start = position / fps
    off_sample = off_packed = off_proposed = 0
    for frame, timestamp in enumerate(times):
        query = start + timestamp
        index = bisect_left(points, query)
        distance = min(
            abs(query - points[min(index, len(points) - 1)]),
            abs(query - points[max(index - 1, 0)]),
        )
        off_sample += distance > TOL
        ordinal = position + frame
        if ordinal >= len(points):
            off_packed += 1
            off_proposed += 1
        else:
            off_packed += not near(query, points[ordinal])
            off_proposed += not near(packed_start + timestamp, points[ordinal])
    return off_sample, off_packed, off_proposed


def inspect_camera(root, info, camera, episodes, timestamps, report, referenced):
    fps = info["fps"]
    prefix = f"videos/{camera}/"
    files = defaultdict(list)
    for row in episodes:
        key = tuple(row[prefix + field] for field in VIDEO_COLUMNS[:2])
        files[key].append(row)
    records, rows = [], []
    for key, group in files.items():
        path = file_path(info["video_path"], "videos", key, video_key=camera)
        require(path not in referenced, f"multiple video references use {path}")
        referenced.add(path)
        context = {"camera": camera, "file": path.as_posix()}
        try:
            with (root / path).open("rb") as stream:
                points, durations = view(stream)
            require(points, "empty video index")
        except (
            OSError,
            MP4Refused,
            Refused,
            StructError,
            IndexError,
            TypeError,
            ZeroDivisionError,
        ) as exc:
            report["issues"].append(
                {
                    "code": "video_index_unavailable",
                    **context,
                    "episodes": [row["episode_index"] for row in group],
                    "detail": exc.strerror if isinstance(exc, OSError) else str(exc),
                }
            )
            continue
        lengths = sum(row["length"] for row in group)
        packed = len(points) == lengths
        if not packed:
            report["issues"].append(
                {
                    "code": "video_sample_count",
                    **context,
                    "episode_frames": lengths,
                    "video_samples": len(points),
                }
            )
        regular = all(near(p, i / fps) for i, p in enumerate(points)) and all(
            near(duration, 1 / fps) for duration in durations
        )
        if not regular:
            report["issues"].append({"code": "unsupported_video_grid", **context})
        end = points[-1] + durations[-1]
        records.append(
            {
                "check": "file",
                "vk": camera,
                "file": list(key),
                "container": len(points),
                "meta": lengths,
                "first_pts": points[0],
                "end": end,
            }
        )
        position = 0
        for episode in group:
            number, length = episode["episode_index"], episode["length"]
            start, stop = (episode[prefix + endpoint] for endpoint in VIDEO_COLUMNS[2:])
            require(
                finite_number(start) and finite_number(stop) and start < stop,
                f"{camera}, episode {number}: invalid camera timestamps",
            )
            last = position + length - 1
            off_sample, off_packed, off_proposed = query_checks(
                points, timestamps[number], start, position, fps
            )
            real_from = points[position] if position < len(points) else None
            real_to = points[last] + durations[last] if last < len(points) else None
            if (
                off_packed
                or real_to is None
                or not near(stop, real_to)
                or not near(start, real_from)
            ):
                report["affected_episodes"].append(
                    {
                        **context,
                        "episode": number,
                        "rows": length,
                        "stored_interval_s": [start, stop],
                        "packed_interval_s": [real_from, real_to],
                        "packed_layout": "compatible"
                        if packed and regular
                        else "unresolved",
                        "queries_off_any_sample": off_sample,
                        "queries_off_packed_time": off_packed,
                    }
                )
            if off_proposed and packed and regular:
                report["issues"].append(
                    {
                        "code": "packed_queries_unaligned",
                        **context,
                        "episode": number,
                        "rows": off_proposed,
                    }
                )
            rows.append(
                {
                    "ep": number,
                    "file": list(key),
                    "pos": position,
                    "len": length,
                    "from": start,
                    "to": stop,
                    "real_from": real_from,
                    "real_to": real_to,
                }
            )
            position += length
    return [*records, {"check": "episodes", "vk": camera, "fps": fps, "rows": rows}]


def try_relayout(root, info, cameras, episodes, timestamps, stored, report):
    """Second path for an archive the timestamp check cannot place: episodes pointing at the wrong video
    file (LeRobot #2550 bug 1), alone or with a carried offset (bug 2). Frames are taken to be packed in
    episode order across each camera's files; plan_relayout refuses unless every sample is used exactly
    once and every row query lands on its own sample. Every MP4 below videos/, at any depth, must be a
    declared camera's chunk/file MP4: the relayout reads each one, and the copy's table must reference them
    all."""
    if any(
        issue["code"] not in RELAYOUT_ISSUES
        or (issue["code"] == "video_inventory_disagrees" and issue["missing"])
        for issue in report["issues"]
    ) or not any(
        issue["code"] in ("video_sample_count", "video_inventory_disagrees")
        for issue in report["issues"]
    ):
        return
    fps, edits = info["fps"], []
    try:
        outside = sorted(
            str(path) for path in stored if len(path.parts) != 4 or path.parts[1] not in cameras
        )
        require(
            not outside,
            f"stored video files outside the declared cameras' chunk folders: {outside}",
        )
        for camera in cameras:
            files = []
            for path in sorted(p for p in stored if p.parts[1] == camera):
                match = VIDEO_FILE.fullmatch("/".join(path.parts[2:]))
                require(match is not None, f"unexpected video file name {path}")
                key = (int(match[1]), int(match[2]))
                require(
                    file_path(info["video_path"], "videos", key, video_key=camera) == path,
                    f"video file {path} does not match the path template",
                )
                with (root / path).open("rb") as stream:
                    points, durations = view(stream)
                files.append((key, points, durations))
            files.sort(key=lambda item: item[0])
            prefix = f"videos/{camera}/"
            rows = [
                {
                    "episode_index": row["episode_index"],
                    "length": row["length"],
                    "file": (row[prefix + "chunk_index"], row[prefix + "file_index"]),
                    "from": row[prefix + "from_timestamp"],
                    "to": row[prefix + "to_timestamp"],
                }
                for row in episodes
            ]
            edits.extend(camera_relayout(camera, files, rows, timestamps, fps))
    except (
        OSError,
        MP4Refused,
        StructError,
        IndexError,
        KeyError,
        OverflowError,
        TypeError,
        ValueError,
        ZeroDivisionError,
    ) as exc:
        detail = exc.strerror if isinstance(exc, OSError) else str(exc)
        report["issues"].append({"code": "relayout_refused", "detail": detail})
        return
    if not edits:
        report["issues"].append(
            {"code": "relayout_refused", "detail": "packed layout equals the stored one"}
        )
        return
    report.update(
        status="relayout_candidate",
        plan={
            "kind": "relayout",
            "dataset": DATASET,
            "fps": fps,
            "episodes": len(episodes),
            "cameras": len(cameras),
            "edits": edits,
        },
    )


def preflight(root, report):
    info = json.loads((root / "meta/info.json").read_text(encoding="utf-8"))
    fps = info["fps"]
    cameras = sorted(
        name
        for name, feature in info["features"].items()
        if feature["dtype"] == "video"
    )
    require(
        info["codebase_version"] == "v3.0"
        and cameras
        and type(fps) in (int, float)
        and isfinite(fps)
        and 0 < fps < 0.5 / TOL,
        "expected a LeRobot v3.0 archive with video and valid fps",
    )
    episodes, data_files, frames = episode_index(root, info, cameras)
    timestamps, tabular_rows = tabular_timestamps(root, data_files)
    episode_count, frame_count = (
        info.get(key) for key in ("total_episodes", "total_frames")
    )
    report["counts"] = {
        "declared_episodes": episode_count if type(episode_count) is int else None,
        "stored_episodes": len(episodes),
        "declared_frames": frame_count if type(frame_count) is int else None,
        "episode_frames": frames,
        "stored_tabular_rows": tabular_rows,
    }
    for key, declared, stored in (
        ("total_episodes", report["counts"]["declared_episodes"], len(episodes)),
        ("total_frames", report["counts"]["declared_frames"], tabular_rows),
    ):
        if declared != stored:
            report["issues"].append(
                {
                    "code": "info_count_disagrees",
                    "field": key,
                    "declared": declared,
                    "stored": stored,
                }
            )
    records = [
        {
            "check": "info",
            "version": "v3.0",
            "fps": fps,
            "video_keys": cameras,
            "total_episodes": len(episodes),
            "total_frames": frames,
        }
    ]
    referenced = set()
    for camera in cameras:
        records.extend(
            inspect_camera(root, info, camera, episodes, timestamps, report, referenced)
        )
    stored = stored_videos(root)
    if stored != referenced:
        report["issues"].append(
            {
                "code": "video_inventory_disagrees",
                "missing": sorted(str(p) for p in referenced - stored),
                "unreferenced": sorted(str(p) for p in stored - referenced),
            }
        )
    if report["issues"]:
        return try_relayout(root, info, cameras, episodes, timestamps, stored, report)
    records.append({"check": "ds_done"})
    records = [dict(row, ds=DATASET) for row in records]
    try:
        plan = build_plan(records, DATASET)
    except Refused as exc:
        report["issues"].append(
            {"code": "unsupported_timestamp_pattern", "detail": str(exc)}
        )
        return
    edited = {(edit["camera"], edit["episode_index"]) for edit in plan["edits"]}
    for row in report["affected_episodes"]:
        if (
            row["queries_off_packed_time"]
            and (row["camera"], row["episode"]) not in edited
        ):
            report["issues"].append(
                {
                    "code": "unresolved_stored_queries",
                    "camera": row["camera"],
                    "episode": row["episode"],
                    "rows": row["queries_off_packed_time"],
                }
            )
    if report["issues"]:
        return
    if plan["edits"]:
        report.update(status="rollover_candidate", plan=plan)
    else:
        report["status"] = "aligned"
    return records


def check_archive(root):
    report = {
        "status": "needs_review",
        "tolerance_s": TOL,
        "issues": [],
        "affected_episodes": [],
    }
    records = None
    try:
        records = preflight(root, report)
    except (
        AttributeError,
        KeyError,
        OSError,
        OverflowError,
        TypeError,
        ValueError,
    ) as exc:
        report["issues"].append(
            {"code": "archive_unreadable_or_inconsistent", "detail": str(exc)}
        )
    except Exception as exc:  # any other failure on a malformed archive still gives a report
        report["issues"].append(
            {
                "code": "archive_unreadable_or_inconsistent",
                "detail": f"{type(exc).__name__}: {exc}",
            }
        )
    try:
        json.dumps(report, allow_nan=False)
    except Exception as exc:  # a value the report cannot carry withholds the details, not the report
        report = {
            "status": "needs_review",
            "tolerance_s": TOL,
            "issues": [
                {
                    "code": "archive_unreadable_or_inconsistent",
                    "detail": f"report not encodable as JSON: {type(exc).__name__}: {exc}",
                }
            ],
            "affected_episodes": [],
        }
        records = None
    return report, records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "archive", type=Path, help="local archive containing meta/info.json"
    )
    args = parser.parse_args()
    report, _ = check_archive(args.archive)
    print(json.dumps(report, indent=2, allow_nan=False))
    return 2 if report["status"] == "needs_review" else 0


if __name__ == "__main__":
    raise SystemExit(main())
