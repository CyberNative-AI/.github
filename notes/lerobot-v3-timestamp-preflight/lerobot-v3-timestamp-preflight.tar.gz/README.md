# Check a LeRobot v3 archive's video timestamps before merging

Two command-line tools for a LeRobot v3.0 dataset on your own disk:

- `local_preflight.py` compares each episode's stored camera timestamps with
  the frame index of the MP4 file it points to. It reads the archive and
  changes nothing.
- `local_repair.py` fixes one known timestamp pattern, the file rollover
  described below, in a new copy of the archive. The original stays as it was.

Both are written for Python 3.12 with PyArrow, and were run with Python 3.12.16
and PyArrow 26.0.1 on Linux x86-64. Neither tool imports LeRobot.

## The pattern this kit repairs

In a LeRobot v3 archive, many episodes share one MP4 per camera, and
`meta/episodes` stores where each episode starts and ends inside that file.
When a camera's recording continues into a new MP4 file, the stored start and
end times of the later episodes should restart from that file's beginning. In
the rollover pattern they keep counting the duration of the earlier files, so
they point past the end of the file they name.

Reading such an episode raises an error in LeRobot 0.7.0 (`FrameTimestampError`
with PyAV, `IndexError` with TorchCodec). Merging the archive with another one
is worse: in our generated checks, the merged archive returned frames from the
wrong episode on some rows without raising any error.

One known cause is LeRobot's own merge in releases 0.4.0 to 0.4.2, whose merge
module (`datasets/aggregate.py`) is identical. When a merge starts a new MP4
file and then appends another source to it, that source's times keep the
duration of the earlier files. LeRobot fixed this in pull request #2550; 0.4.3
is the first release with the fix. We reproduced it with LeRobot 0.4.2, and this kit's repaired copy
of that merge stores the same times as LeRobot 0.7.0's merge of the same
sources. Other versions or workflows may write the same pattern.

## Check an archive

Save the archive and its companion `SHA256SUMS` in one directory. In Bash on
Linux, confirm the archive, extract it and confirm its files:

```bash
sha256sum --strict --check SHA256SUMS &&
  mkdir timestamp-kit &&
  tar -xzf lerobot-v3-timestamp-preflight.tar.gz -C timestamp-kit &&
  cd timestamp-kit &&
  sha256sum --strict --check SHA256SUMS
```

Point the preflight at the directory that holds `meta/info.json`:

```bash
python -B local_preflight.py /path/to/archive > preflight.json
echo "exit $?"
```

It writes a JSON report and exits with one of these results:

| `status` | Exit | Meaning |
| --- | ---: | --- |
| `aligned` | 0 | Every stored camera timestamp lands on the expected frame of its MP4 file, within 0.1 ms. |
| `rollover_candidate` | 0 | The archive has the rollover pattern, and every timestamp lands on its expected frame after the edits listed in `plan`. |
| `needs_review` | 2 | Something else disagrees: totals in `info.json`, a missing or unreadable file, a frame count, or timestamps that fit no supported pattern. When a problem belongs to one camera, file or episode, its entry in `issues` or `affected_episodes` names them. A problem that stops the check gives one `archive_unreadable_or_inconsistent` issue whose `detail` says what was wrong, for example an `info.json` that does not parse, a path template the preflight does not support, or a timestamp stored as anything other than a finite integer or floating-point number. If the report would hold a value that JSON cannot carry, that single issue replaces its details. |

`affected_episodes` gives two counts per camera and episode.
`queries_off_any_sample` counts stored timestamps that match no frame in the
file. `queries_off_packed_time` counts timestamps that miss the frame expected
from the episode's position in the file. A timestamp can land exactly on a real
frame of the wrong episode, so the second count can be nonzero when the first
is zero.

The preflight reads `meta/info.json`, the episode and data Parquet files, and
the index of each referenced MP4. It does not decode video. It follows symbolic
links, for example in a Hugging Face cache snapshot.

## Repair a copy

Use this when the preflight returns `rollover_candidate`. The archive must have
one episode Parquet file under `meta/episodes`, regular files only and no other
process writing to it. Both commands first resolve the archive path you give
them, so a symbolic link to the archive directory itself is followed; they then
refuse any symbolic link inside the archive. The destination needs room for a
full copy.

```bash
source_archive=/path/to/archive
work=$(mktemp -d)
python -B local_repair.py plan "$source_archive" > "$work/candidate.json"
echo "exit $?"
```

`plan` saves the proposed edits together with the size and SHA-256 of every
file in the archive. Read the old and new times in `candidate.json`, then
make the copy:

```bash
python -B local_repair.py copy "$source_archive" "$work/candidate.json" "$work/repaired" > "$work/receipt.json"
echo "exit $?"
```

A refusal prints its reason and exits 2. `copy` checks every source file against those hashes, copies the
archive to a temporary directory beside the destination, makes the plan again
on that copy and requires it to equal the saved one. It then rewrites only the
episode Parquet, requires the preflight on the copy to return `aligned`, checks
the hashes again and only then moves the copy to the destination you named. It
refuses, and writes nothing at the destination, if the destination exists or
lies inside the source, the source has changed, or the plans differ. The
receipt lists the edits and the new Parquet's hash.

The commands never write to the source archive. To undo, delete the copy and
keep using the original.

## Merge the repaired copy

Merge the repaired copy as you would the original, then run the preflight on
the result. Our checks used this form of LeRobot 0.7.0's editor, with the Hub
in offline mode so that it reads only the local copies, and with uploading
switched off:

```bash
HF_HUB_OFFLINE=1 python -m lerobot.scripts.lerobot_edit_dataset \
  --new_repo_id local/merged --new_root "$work/merged" \
  --operation.type merge \
  --operation.repo_ids '["local/repaired", "local/other"]' \
  --operation.roots "[\"$work/repaired\", \"/path/to/other/archive\"]" \
  --push_to_hub false
python -B local_preflight.py "$work/merged"
```

Replace the repo IDs and the second root with your own. The roots list is JSON,
so a path containing a double quote or backslash needs escaping.

## What the kit does not do

- It does not decode frames or check that cameras were captured in sync. It
  checks that each stored timestamp selects the frame at the episode's position
  in the file.
- It repairs only the rollover pattern, at a constant frame rate, in an archive
  with one episode Parquet. Every other disagreement returns `needs_review` for
  you to inspect.
- It does not repair a merge whose episodes point at the wrong MP4 file. The
  same LeRobot releases did this when a merge started a new MP4 file partway
  through one source's videos: that source's earlier episodes kept their times
  but pointed at its last file (also fixed by #2550). In our two reproductions
  with 0.4.2, the preflight returned `needs_review` with `video_sample_count`,
  because a file was referenced by more frames than it holds. In one of them,
  LeRobot returned frames from other episodes without an error.
  `video_sample_count` has other possible causes, such as a truncated video
  file. If the archive was merged with those releases and you still have the
  sources, merge them again with a current release; LeRobot 0.7.0's merges of
  the same sources read every row correctly in our checks.
- It reads LeRobot v3.0 archives only.
- The checks below use generated archives recorded with LeRobot 0.7.0, H.264
  video at a constant 8 fps and one merge order. The LeRobot 0.4.2 merges
  described above were run separately, with AV1 video at 8 fps, and are not
  part of these checks. Other LeRobot versions and physical recordings were not
  tested.

## Run the checks

The checks record small archives with LeRobot 0.7.0's own writer, plant the
rollover pattern, run both tools, merge with LeRobot's editor and read every
row with PyAV and TorchCodec. The reference environment took 1.7 GB on disk.
Once it is installed, the checks run with the Hugging Face Hub offline.

The checks need Python 3.12.16 exactly: `merge/result.json` records the
interpreter version, so its expected hash holds only on that release, and
`checks/check_env.py` refuses any other. The reference run used CPU wheels on
Linux x86-64. Install Python 3.12.16 with its `venv` module, then run this from
the extracted kit. The packages come from PyPI and the PyTorch CPU wheel index.

```bash
python3.12 -c 'import sys; assert sys.version_info[:3] == (3, 12, 16), sys.version' &&
  python3.12 -m venv .venv &&
  source .venv/bin/activate &&
  python -m pip install --only-binary=:all: --index-url https://download.pytorch.org/whl/cpu \
    'torch==2.15.0+cpu' 'torchvision==0.29.2+cpu' 'torchcodec==0.17.0+cpu' &&
  python -m pip install --only-binary=:all: -r requirements.txt &&
  python -m pip check
```

TorchCodec loads FFmpeg by its standard library names. Point it at the FFmpeg
7.1 libraries inside the PyAV 15.1.0 wheel:

```bash
work=$(mktemp -d)
mkdir "$work/ffmpeg"
avlibs=$(python -c 'from pathlib import Path; import av; print(Path(av.__file__).resolve().parent.parent / "av.libs")')
shopt -s nullglob
for library in avutil:59 avcodec:61 avformat:61 avdevice:61 avfilter:10 swscale:8 swresample:5; do
  name=${library%:*}
  major=${library#*:}
  candidates=("$avlibs"/lib"$name"-*.so."$major".*)
  if [[ ${#candidates[@]} -ne 1 ]]; then
    echo "expected one lib$name.so.$major in $avlibs" >&2
  fi
  ln -s -- "${candidates[0]}" "$work/ffmpeg/lib$name.so.$major"
done
shopt -u nullglob
export LD_LIBRARY_PATH="$work/ffmpeg"
bash checks/run_checks.sh "$work/checks"
```

`run_checks.sh` refuses an output directory that already exists, whose parent
does not exist, or that resolves to a place inside the kit, and then creates
nothing. Otherwise it checks the kit against `SHA256SUMS` and sets the Hugging
Face cache and the temporary directory inside the output directory, with the
Hub offline. It runs seven steps in order, the first of which checks the
Python version and the installed versions against `requirements.txt`. It
writes each step's exit code to `summary.jsonl` and stops at the first
failure. It passes only if `summary.jsonl` holds exactly the seven step
records, each with exit code 0, and the five result files match
`checks/EXPECTED-OUTPUTS.sha256`. The last line reads
`OK 7 steps passed; 5 outputs match EXPECTED-OUTPUTS.sha256`.

Every run of `local_preflight.py` and `local_repair.py` in the checks goes
through `checks/guard.py`, which adds a Python audit hook. The hook raises an
error on the audit events it lists: socket events, `urllib.Request`,
`http.client.connect`, the `ftplib` and `smtplib` connects, `webbrowser.open`,
`subprocess.Popen` and the `os` events for `system`, `exec`, `fork`,
`posix_spawn`, `spawn` and `startfile`. Controls in `check_preflight.py`
confirm that it stops a socket, `urllib.request.urlopen`, `subprocess.run` and
`os.system`; the other events are not tested one by one. It sees only calls
that raise those events. Native code that opens a connection or starts a
process without them, for example a compiled extension calling the operating
system directly, is outside what it can observe.

| Step | What it shows |
| --- | --- |
| `unit` | Six tests of the planner and the Parquet writer. |
| `demo` | One camera, three episodes, 24 frames in two MP4 files, with the rollover planted in episode 2. Before the repair, PyAV and TorchCodec each fail on the same 7 rows. After it, each returns the expected frame on all 24 rows, including both sides of every join. Six other files keep their hashes. |
| `merge` | Merging the unrepaired archive with a 14-frame clean archive makes both readers return a frame from another episode on 7 rows, without an error. After the repair, the merged archive returns the expected frame on all 38 rows. |
| `preflight` | The report on the clean, rollover, unrepaired-merge and repaired-merge archives. Two planted offsets of 0.07 ms, each under the 0.1 ms tolerance, on episode 2's stored start and on one of its row timestamps, together move one row out of tolerance, and the report returns `needs_review` naming it. A tree of symbolic links gives the same report as the files it points to, and `local_repair.py plan` refuses it; a symbolic link to the archive directory gives the same plan as the archive. Four malformed copies (a positional field in `data_path`, an oversized width in `video_path`, an `info.json` that is not JSON, and one nested too deeply to parse) each return `needs_review` as JSON with exit 2 and stay unchanged. So do two copies of the rollover archive with timestamps stored as decimals, one in a camera's end times and one in the row timestamps. Two faults planted inside the tools reach the last-resort paths: a value the report cannot carry gives `needs_review` with that single issue and exit 2, and an unexpected error in `local_repair.py plan` gives `Refused: unexpected` with exit 2. The step also runs the four guard controls described above. |
| `copy` | `plan` and `copy` repeat byte for byte, and only the episode Parquet changes. The repaired table equals the clean one. The copy and its merge with a clean archive return the expected frame on all 24 and 38 rows on both readers. Six refusals: existing destination, destination inside the source, an `aligned` archive, an edited plan, a changed video of the same size, and two episode Parquets. |
| `multicam` | Two cameras that change MP4 files and roll over at different episodes (8 episodes, 62 frames). The preflight proposes exactly the 4 planted edits. The repaired copy returns the expected frame on all 62 rows, and its merge with a clean two-camera archive on all 74, for both cameras and both readers. Merging without the repair returns frames from other episodes on 10 rows without an error, and the preflight on that merge returns `needs_review` naming all four affected episodes. |

`checks/replay.py` and the other check scripts can also be read as worked
examples of the LeRobot calls involved.

## Licence

CyberNative AI LLC's code in this kit is available under the Apache License 2.0
in `LICENSE`.

Prepared by CyberNative AI LLC, an AI-run company, using AI agents.
