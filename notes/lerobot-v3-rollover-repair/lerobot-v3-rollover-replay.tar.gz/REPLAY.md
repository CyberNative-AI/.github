# Replay the LeRobot v3 rollover repair

This replay checks one pinned archive, [Themistoflix/ginger_back_merged](https://huggingface.co/datasets/Themistoflix/ginger_back_merged/tree/8604d54b1727ee017f2b97f47a716f6ed38f0690).
It generates a separate replacement for `meta/episodes/chunk-000/file-000.parquet`.
Keep the source directory for comparison or restoration. The archive download is
1,364,677,413 bytes. Budget additional space for Python packages and local outputs.

## Check and extract the kit

Run these commands in Bash on Linux x86-64, with GNU coreutils, tar, and curl.
Save the archive and its companion `SHA256SUMS` in the same directory.

```bash
set -euo pipefail
sha256sum --strict --check SHA256SUMS
mkdir rollover-kit
tar -xzf lerobot-v3-rollover-replay.tar.gz -C rollover-kit
cd rollover-kit
sha256sum --strict --check SHA256SUMS
export EXPECTED_MANIFEST_SHA256=$(sha256sum SHA256SUMS | cut -d ' ' -f1)
```

## Prepare the decoder environment

The reference run used CPU wheels on Linux x86-64 and Python 3.12.16. Install
Python 3.12 with its `venv` module, then run this setup from the extracted kit.
The Python packages come from PyPI and the PyTorch CPU wheel index.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --only-binary=:all: --index-url https://download.pytorch.org/whl/cpu \
  'torch==2.15.0+cpu' 'torchvision==0.29.2+cpu' 'torchcodec==0.17.0+cpu'
python -m pip install --only-binary=:all: -r requirements.txt
python -m pip check
```

The exact pixel hashes use the FFmpeg 7.1 libraries in the PyAV 15.1.0 Linux wheel.
Create the library names that TorchCodec expects in a separate directory.

```bash
work=$(mktemp -d "$PWD/rollover-work.XXXXXXXX")
mkdir "$work/ffmpeg" "$work/scratch"
avlibs=$(python -c 'from pathlib import Path; import av; print(Path(av.__file__).resolve().parent.parent / "av.libs")')
shopt -s nullglob
for library in avutil:59 avcodec:61 avformat:61 avdevice:61 avfilter:10 swscale:8 swresample:5; do
  name=${library%:*}
  major=${library#*:}
  candidates=("$avlibs"/lib"$name"-*.so."$major".*)
  [[ ${#candidates[@]} -eq 1 ]]
  ln -s -- "${candidates[0]}" "$work/ffmpeg/lib$name.so.$major"
done
shopt -u nullglob
export LD_LIBRARY_PATH="$work/ffmpeg"
python -c 'import av; from torchcodec.decoders import VideoDecoder'
```

## Get the source and run the replay

```bash
python -B acquire_snapshot.py "$work/source"
export ORIGINAL_SNAPSHOT="$work/source"
export TMPDIR="$work/scratch"
bash replay.sh
```

Acquisition uses anonymous HTTPS requests for the 17 listed paths at the exact
Hub revision. It checks every file's length and SHA-256. You can reuse a clean
local copy by setting `ORIGINAL_SNAPSHOT` to its directory. It must contain
the 17 listed regular files at their listed paths. Keep `TMPDIR` writable,
outside that directory, and on the same filesystem for the verifier's hard links.
Keep both directories free of concurrent edits during replay.

The script prints a new output directory and checks the generated replacement
Parquet, apply receipt and both decoder reports against `EXPECTED-OUTPUTS.sha256`.
It stops on the first failed comparison. Each backend reads 238 boundary and
endpoint rows via LeRobot's normal dataset index. The check expects 60 original
failures and the exact stored reference pixels in both cameras on all 238 rows
after the repair. It checks the entire source inventory again after reading.
The read proves stored frame selection for this archive. Capture-time
synchronization remains unverified.

## Restore the original metadata

Discard the generated outputs. If you installed the replacement in another
working copy, restore the original episode Parquet from the pinned source.
Its SHA-256 is `9db02846e06c796329021c1e6113c6ace0a928718f1f8f140a611040cff92330`.

CyberNative AI LLC's code and timing measurements in this kit are available
under Apache-2.0. The source archive has its own terms on the Hub.
Prepared by CyberNative AI LLC, an AI-run company, using AI agents.
