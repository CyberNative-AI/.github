"""Build a read-only timestamp patch from a complete M25 cases.py audit.

Recognize the observed v3 rollover signature: a clean prefix followed by
timestamps that include the duration of all earlier files for that camera.
The audit must agree with a constant-rate grid at every episode boundary.
A candidate plan contains old and new values for later copy-only apply.
"""

import argparse
from collections import defaultdict
import gzip
import json
import math
from pathlib import Path


TOL = 1e-4


class Refused(ValueError):
    pass


def near(a, b):
    return math.isclose(a, b, rel_tol=0, abs_tol=TOL)


def one(rows, kind, **fields):
    matches = [row for row in rows if row["check"] == kind
               and all(row.get(k) == v for k, v in fields.items())]
    if len(matches) != 1:
        raise Refused(f"expected one {kind} record for {fields}")
    return matches[0]


def camera_patch(records, camera, count, total_frames, fps):
    audit = one(records, "episodes", vk=camera)
    rows = sorted(audit["rows"], key=lambda row: row["ep"])
    if [row["ep"] for row in rows] != list(range(count)) or audit["fps"] != fps:
        raise Refused(f"{camera}: incomplete episode coverage or inconsistent fps")
    files = defaultdict(list)
    for row in rows:
        files[tuple(row["file"])].append(row)
    seen_order = list(files)
    file_order = [tuple(row["file"]) for row in rows]
    if file_order != sorted(file_order):
        raise Refused(f"{camera}: episodes do not follow file order")
    file_records = [r for r in records if r["check"] == "file" and r["vk"] == camera]
    if sorted(tuple(r["file"]) for r in file_records) != seen_order:
        raise Refused(f"{camera}: missing, unused or duplicate video file record")

    edits = []
    earlier_frames = 0
    for key, episodes in files.items():
        video = one(file_records, "file", file=list(key))
        prefix = f"{camera} {list(key)}"
        frames = video["container"]
        if (not isinstance(frames, int) or frames <= 0 or video["meta"] != frames
                or not near(video["first_pts"], 0) or not near(video["end"], frames / fps)):
            raise Refused(f"{prefix}: frame count or file timing disagrees with metadata")
        position = 0
        repairing = False
        for row in episodes:
            length = row["len"]
            if not isinstance(length, int) or length <= 0 or row["pos"] != position:
                raise Refused(f"{prefix}: invalid episode length or position")
            start = position / fps
            position += length
            end = position / fps
            if (position > frames or row["real_from"] is None or row["real_to"] is None
                    or not near(row["real_from"], start) or not near(row["real_to"], end)):
                raise Refused(f"{prefix}: episode boundaries disagree with the file frame grid")

            old_start, old_end = row["from"], row["to"]
            if not repairing and near(old_start, start) and near(old_end, end):
                continue
            carry = earlier_frames / fps
            if (carry <= 2 * TOL or row is episodes[0]
                    or not near(old_start, start + carry) or not near(old_end, end + carry)):
                raise Refused(f"{prefix}: episode {row['ep']} has an unsupported timestamp pattern")
            repairing = True
            edits.append({"camera": camera, "file": list(key), "episode_index": row["ep"],
                          "first_frame": row["pos"], "length": length,
                          "old_from": old_start, "old_to": old_end,
                          "new_from": start, "new_to": end})
        if position != frames:
            raise Refused(f"{prefix}: episodes do not account for all video frames")
        earlier_frames += frames
    if earlier_frames != total_frames:
        raise Refused(f"{camera}: video frame total disagrees with dataset info")
    return edits


def build_plan(records, dataset):
    records = [row for row in records if row.get("ds") == dataset]
    meta = one(records, "info")
    one(records, "ds_done")
    if any(row["check"] in {"file_error", "error"} for row in records):
        raise Refused("audit has missing files or a dataset error")
    fps, count, total = meta["fps"], meta["total_episodes"], meta["total_frames"]
    cameras = meta["video_keys"]
    if (meta["version"] != "v3.0" or not math.isfinite(fps) or fps <= 0
            or not isinstance(count, int) or count <= 0 or not isinstance(total, int)
            or total <= 0 or not cameras or len(set(cameras)) != len(cameras)):
        raise Refused("expected complete LeRobot v3.0 metadata with video")
    edits = []
    for camera in cameras:
        edits.extend(camera_patch(records, camera, count, total, fps))
    return {"dataset": dataset, "fps": fps, "episodes": count, "cameras": len(cameras),
            "edits": edits}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audit", type=Path, help="cases.py JSONL output, optionally gzip-compressed")
    parser.add_argument("dataset", help="exact dataset identifier in the audit")
    args = parser.parse_args()
    try:
        open_audit = gzip.open if args.audit.suffix == ".gz" else open
        with open_audit(args.audit, "rt", encoding="utf-8") as stream:
            plan = build_plan([json.loads(line) for line in stream], args.dataset)
    except (KeyError, OSError, TypeError, ValueError) as exc:
        parser.exit(2, f"Refused: {exc}\n")
    print(json.dumps(plan, allow_nan=False, indent=2))


if __name__ == "__main__":
    main()
