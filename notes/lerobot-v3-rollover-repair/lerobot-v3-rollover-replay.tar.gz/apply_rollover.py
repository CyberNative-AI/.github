"""Write one replacement episode Parquet from a pinned, local v3 snapshot."""

import argparse
from collections import defaultdict
import gzip
import hashlib
import json
import os
from pathlib import Path
import tempfile

import pyarrow as pa
import pyarrow.parquet as pq

from plan_rollover import Refused, build_plan


SOURCE_MANIFEST_SHA256 = "0330621746d410c42f36e62087f8c8abe062c85da9df6f5150fbc8f1df584abd"
TIMING_AUDIT_SHA256 = "3a3058220aa34ff445abd2dabd5633491a59a9194c55e61e55cded733b77975e"


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def verify_snapshot(root, manifest):
    paths = list(root.rglob("*"))
    if any(path.is_symlink() for path in paths):
        raise Refused("snapshot contains symbolic links")
    files = {path.relative_to(root).as_posix(): path for path in paths if path.is_file()}
    if files.keys() != manifest.keys():
        raise Refused("snapshot inventory differs from the pinned manifest")
    for name, path in sorted(files.items()):
        expected = manifest[name]
        if path.stat().st_size != expected["size"] or sha256(path) != expected["sha256"]:
            raise Refused(f"snapshot bytes differ for {name}")


def patch_episode_table(table, plan):
    episodes = table["episode_index"].to_pylist()
    if sorted(episodes) != list(range(plan["episodes"])):
        raise Refused("episode indices differ from the audit")
    row_by_episode = {value: row for row, value in enumerate(episodes)}
    updates = defaultdict(dict)
    for edit in plan["edits"]:
        row = row_by_episode[edit["episode_index"]]
        prefix = f"videos/{edit['camera']}/"
        if (table["length"][row].as_py() != edit["length"]
                or [table[prefix + key][row].as_py() for key in ("chunk_index", "file_index")]
                != edit["file"]):
            raise Refused(f"episode {episodes[row]} length or file differs from the audit")
        for endpoint in ("from", "to"):
            column = prefix + endpoint + "_timestamp"
            if row in updates[column] or table[column][row].as_py() != edit[f"old_{endpoint}"]:
                raise Refused(f"episode {episodes[row]} has a duplicate edit or different {column}")
            updates[column][row] = edit[f"new_{endpoint}"]
    for column, replacements in updates.items():
        field = table.schema.field(column)
        if not pa.types.is_float64(field.type):
            raise Refused(f"{column} is not float64")
        values = table[column].to_pylist()
        for row, value in replacements.items():
            values[row] = value
        table = table.set_column(table.schema.get_field_index(column), field, pa.array(values, type=field.type))
    return table


def _write_replacement(source, manifest, audit, output):
    dataset = manifest["dataset"]
    revision = manifest["revision"]
    inventory = manifest["files"]
    source = source.resolve(strict=True)
    output = output.parent.resolve(strict=True) / output.name
    if output.is_relative_to(source):
        raise Refused("output must be outside the source snapshot")
    verify_snapshot(source, inventory)
    files = sorted(source.glob("meta/episodes/**/*.parquet"))
    if len(files) != 1:
        raise Refused("this writer requires one episode Parquet shard")
    plan = build_plan(audit, dataset)
    if not plan["edits"]:
        raise Refused("no supported rollover edits")
    relative = files[0].relative_to(source)
    original = files[0].read_bytes()
    if hashlib.sha256(original).hexdigest() != inventory[relative.as_posix()]["sha256"]:
        raise Refused("episode Parquet changed after snapshot verification")
    table = pq.ParquetFile(pa.BufferReader(original)).read()
    updated = patch_episode_table(table, plan)
    with tempfile.TemporaryDirectory(dir=output.parent, ignore_cleanup_errors=True) as temp:
        staged = Path(temp) / "episodes.parquet"
        pq.write_table(updated, staged)
        restored = pq.ParquetFile(staged).read()
        if not restored.equals(updated, check_metadata=True):
            raise Refused("replacement Parquet did not round-trip")
        receipt = json.dumps({
            "dataset": dataset,
            "revision": revision,
            "path": relative.as_posix(),
            "edits": plan["edits"],
            "sha256": sha256(staged),
        }, indent=2)
        os.link(staged, output)
    return receipt


def apply(source, manifest_path, audit_path, output):
    manifest_bytes = manifest_path.read_bytes()
    if hashlib.sha256(manifest_bytes).hexdigest() != SOURCE_MANIFEST_SHA256:
        raise Refused("source manifest SHA-256 differs from the pinned input")
    audit_bytes = audit_path.read_bytes()
    if hashlib.sha256(audit_bytes).hexdigest() != TIMING_AUDIT_SHA256:
        raise Refused("timing audit SHA-256 differs from the pinned input")
    manifest = json.loads(manifest_bytes)
    audit = [json.loads(line) for line in gzip.decompress(audit_bytes).splitlines()]
    return _write_replacement(source, manifest, audit, output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path, help="pinned source manifest")
    parser.add_argument("audit", type=Path, help="pinned gzip-compressed cases.py JSONL audit")
    parser.add_argument("output", type=Path, help="new file outside the source snapshot")
    args = parser.parse_args()
    try:
        receipt = apply(args.source, args.manifest, args.audit, args.output)
    except (OSError, TypeError, ValueError, KeyError) as exc:
        parser.exit(2, f"Refused: {exc}\n")
    print(receipt)


if __name__ == "__main__":
    main()
