"""Compare local before/after LeRobot reads against frames addressed by file ordinal."""

import argparse
from collections import defaultdict
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import shutil

import av  # Load PyAV's FFmpeg before importing TorchCodec in the proof environment.
import pyarrow.parquet as pq
import torch
from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lerobot.datasets.video_utils import FrameTimestampError
from torchcodec.decoders import VideoDecoder

from apply_rollover import sha256, verify_snapshot
from moovpts import parse, sorted_seconds


def digest_frame(frame):
    return hashlib.sha256(frame.contiguous().numpy().tobytes()).hexdigest()


def boundaries(source, metadata):
    info = json.loads((source / "meta/info.json").read_text())
    cameras = [key for key, feature in info["features"].items() if feature["dtype"] == "video"]
    table = pq.ParquetFile(source / metadata).read()
    offsets = defaultdict(int)
    frames_by_file = defaultdict(set)
    samples = []
    for row in sorted(table.to_pylist(), key=lambda row: row["episode_index"]):
        length = row["length"]
        for local in sorted({0, length - 1}):
            positions = {}
            for camera in cameras:
                prefix = f"videos/{camera}/"
                path = info["video_path"].format(
                    video_key=camera, chunk_index=row[prefix + "chunk_index"],
                    file_index=row[prefix + "file_index"],
                )
                index = offsets[path] + local
                positions[camera] = (path, index)
                frames_by_file[path].add(index)
            samples.append((row["episode_index"], local, row["dataset_from_index"] + local, positions))
        for path, _ in positions.values():
            offsets[path] += length
    return samples, frames_by_file, offsets, info["fps"]


def reference_frames(path, indices, count, fps):
    with path.open("rb") as stream:
        timestamps = sorted_seconds(parse(stream))
    if len(timestamps) != count or any(abs(pts - index / fps) > 1e-4 for index, pts in enumerate(timestamps)):
        raise ValueError(f"{path}: MP4 presentation grid disagrees with the episode layout")
    decoder = VideoDecoder(str(path), seek_mode="exact", num_ffmpeg_threads=2)
    if len(decoder) != count:
        raise ValueError(f"{path}: TorchCodec frame count disagrees with the episode lengths")
    hashes = {}
    ordered = sorted(indices)
    for start in range(0, len(ordered), 8):
        batch = ordered[start:start + 8]
        frames = decoder.get_frames_at(batch)
        for frame, index, pts in zip(frames.data, batch, frames.pts_seconds, strict=True):
            if abs(float(pts) - timestamps[index]) > 1e-4:
                raise ValueError(f"{path}: TorchCodec presentation time disagrees at {index}")
            hashes[index] = digest_frame(frame)
    return hashes


def check_item(item, episode, local, index, positions, refs):
    if (int(item["episode_index"]), int(item["frame_index"]), int(item["index"])) != (episode, local, index):
        raise ValueError(f"tabular frame identity differs at dataset row {index}")
    hashes = {camera: digest_frame(item[camera]) for camera in positions}
    for camera, (path, ordinal) in positions.items():
        if hashes[camera] != refs[path][ordinal]:
            raise ValueError(f"{camera}: wrong video frame at dataset row {index}, video ordinal {ordinal}")
    return hashes


def verify(source, manifest, replacement, receipt, dest, report, backend):
    path = receipt["path"]
    if (receipt["dataset"], receipt["revision"]) != (manifest["dataset"], manifest["revision"]):
        raise ValueError("replacement receipt refers to a different dataset revision")
    verify_snapshot(source, manifest["files"])
    if sha256(replacement) != receipt["sha256"] or path not in manifest["files"]:
        raise ValueError("replacement does not match its receipt")
    shutil.copytree(source, dest, copy_function=os.link)
    (dest / path).unlink()
    shutil.copyfile(replacement, dest / path)
    edited = {edit["episode_index"] for edit in receipt["edits"]}
    samples, files, counts, fps = boundaries(source, path)

    print(f"{backend}: preparing ordinal references for {len(files)} video files", flush=True)
    refs = {}
    for name, indices in sorted(files.items()):
        refs[name] = reference_frames(source / name, indices, counts[name], fps)
        print(f"{backend}: {name}: {len(indices)} reference frames", flush=True)

    kwargs = {"video_backend": backend, "return_uint8": True, "token": False}
    original = LeRobotDataset(manifest["dataset"], root=source, **kwargs)
    patched = LeRobotDataset(manifest["dataset"], root=dest, **kwargs)
    with report.open("x") as out:
        for episode, local, index, positions in samples:
            try:
                item = original[index]
            except (FrameTimestampError, IndexError) as exc:
                if episode not in edited:
                    raise
                before = type(exc).__name__
            else:
                check_item(item, episode, local, index, positions, refs)
                if episode in edited:
                    raise ValueError(f"original row {index} unexpectedly read correctly")
                before = "match"
            hashes = check_item(patched[index], episode, local, index, positions, refs)
            out.write(json.dumps({"episode": episode, "frame": local, "index": index,
                                  "original": before, "patched_pixel_sha256": hashes}) + "\n")
            out.flush()

    verify_snapshot(source, manifest["files"])
    after = {**manifest["files"], path: {"sha256": receipt["sha256"], "size": replacement.stat().st_size}}
    verify_snapshot(dest, after)
    print(json.dumps({"backend": backend, "lerobot": version("lerobot"), "samples": len(samples),
                      "cameras": len(samples[0][3]), "original_failed": sum(e in edited for e, *_ in samples),
                      "patched_match": len(samples), "unchanged_files": len(after) - 1}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("replacement", type=Path)
    parser.add_argument("receipt", type=Path)
    parser.add_argument("dest", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("backend", choices=["pyav", "torchcodec"])
    args = parser.parse_args()
    torch.set_num_threads(2)
    if version("lerobot") != "0.7.0":
        raise SystemExit("this proof requires LeRobot 0.7.0")
    verify(args.source, json.loads(args.manifest.read_text()), args.replacement,
           json.loads(args.receipt.read_text()), args.dest, args.report, args.backend)


if __name__ == "__main__":
    main()
