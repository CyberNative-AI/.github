"""Presentation times of every video sample in an mp4, read from the `moov` box only.

Works on any binary file object with seek/read (a local file or huggingface_hub's HfFileSystem file),
so a remote file costs its box headers and its `moov`, not its frames.

Returns times as integers in the track timescale (exact) plus the timescale. The rules mirror what
FFmpeg's mov demuxer gives a reader for the simple layouts LeRobot writes; anything else is refused
with a reason instead of guessed:
  pts = dts + ctts (version 0 offsets, or version 1 offsets that are all >= 0)
  one edit with media_time M >= 0: pts -= M
  an empty edit (media_time -1) then one edit: pts += empty duration (movie timescale -> track timescale)
Refused: fragmented files (moof), more than one non-empty edit, negative composition offsets,
edit rate other than 1, no video track. The M25 gates compare this with PyAV's demuxed pts.
"""

import struct

CONTAINERS = {b"moov", b"trak", b"mdia", b"minf", b"stbl", b"edts"}
MAX_MOOV = 64 << 20


class Refused(Exception):
    pass


def _boxes(buf, start, end):
    pos = start
    while pos + 8 <= end:
        size, typ = struct.unpack(">I4s", buf[pos:pos + 8])
        hdr = 8
        if size == 1:
            size = struct.unpack(">Q", buf[pos + 8:pos + 16])[0]
            hdr = 16
        elif size == 0:
            size = end - pos
        if size < hdr or pos + size > end:
            raise Refused(f"bad box {typ!r} at {pos}")
        yield typ, pos + hdr, pos + size
        pos += size


def _find(buf, start, end, typ):
    for t, s, e in _boxes(buf, start, end):
        if t == typ:
            return s, e
    return None


def read_moov(fh):
    """Bytes of the top-level moov box, located by walking top-level box headers."""
    fh.seek(0, 2)
    size_all = fh.tell()
    pos = 0
    while pos + 8 <= size_all:
        fh.seek(pos)
        h = fh.read(16)
        size, typ = struct.unpack(">I4s", h[:8])
        hdr = 8
        if size == 1:
            size = struct.unpack(">Q", h[8:16])[0]
            hdr = 16
        elif size == 0:
            size = size_all - pos
        if size < hdr:
            raise Refused(f"bad top-level box {typ!r} at {pos}")
        if typ == b"moof":
            raise Refused("fragmented mp4")
        if typ == b"moov":
            if size > MAX_MOOV:
                raise Refused(f"moov {size} B over limit")
            fh.seek(pos)
            data = fh.read(size)
            if len(data) != size:
                raise Refused("short moov read")
            return data
        pos += size
    raise Refused("no moov")


def _full(buf, s):
    return buf[s], s + 4  # version, payload start after version/flags


def parse(fh):
    moov = read_moov(fh)
    n = len(moov)
    ms, me = 8, n
    if moov[4:8] != b"moov":
        raise Refused("moov header")
    if struct.unpack(">I", moov[:4])[0] == 1:
        ms = 16
    mvhd = _find(moov, ms, me, b"mvhd")
    if not mvhd:
        raise Refused("no mvhd")
    v, p = _full(moov, mvhd[0])
    movie_ts = struct.unpack(">I", moov[p + (16 if v == 1 else 8):][:4])[0]
    for t, ts, te in _boxes(moov, ms, me):
        if t != b"trak":
            continue
        mdia = _find(moov, ts, te, b"mdia")
        if not mdia:
            continue
        hdlr = _find(moov, *mdia, b"hdlr")
        if not hdlr or moov[hdlr[0] + 8:hdlr[0] + 12] != b"vide":
            continue
        return _track(moov, ts, te, mdia, movie_ts)
    raise Refused("no video track")


def _track(b, ts, te, mdia, movie_ts):
    mdhd = _find(b, *mdia, b"mdhd")
    v, p = _full(b, mdhd[0])
    timescale = struct.unpack(">I", b[p + (16 if v == 1 else 8):][:4])[0]
    minf = _find(b, *mdia, b"minf")
    stbl = _find(b, *minf, b"stbl")
    stsd = _find(b, *stbl, b"stsd")
    codec = b[stsd[0] + 12:stsd[0] + 16].decode("latin-1") if stsd else None
    stts = _find(b, *stbl, b"stts")
    if not stts:
        raise Refused("no stts")
    _, p = _full(b, stts[0])
    cnt = struct.unpack(">I", b[p:p + 4])[0]
    dts = []
    dur = []
    t = 0
    for i in range(cnt):
        c, d = struct.unpack(">II", b[p + 4 + 8 * i:p + 12 + 8 * i])
        for _ in range(c):
            dts.append(t)
            dur.append(d)
            t += d
    end_dts = t
    ctts = _find(b, *stbl, b"ctts")
    off = [0] * len(dts)
    if ctts:
        v, p = _full(b, ctts[0])
        cnt = struct.unpack(">I", b[p:p + 4])[0]
        k = 0
        for i in range(cnt):
            c, o = struct.unpack(">I" + ("i" if v == 1 else "I"), b[p + 4 + 8 * i:p + 12 + 8 * i])
            if v == 0 and o >= 1 << 31:
                o -= 1 << 32  # FFmpeg reads offsets as signed either way
            if o < 0:
                raise Refused("negative composition offset")
            for _ in range(c):
                if k < len(off):
                    off[k] = o
                k += 1
    shift = 0
    edits = []
    edts = _find(b, ts, te, b"edts")
    if edts:
        elst = _find(b, *edts, b"elst")
        if elst:
            v, p = _full(b, elst[0])
            cnt = struct.unpack(">I", b[p:p + 4])[0]
            q = p + 4
            for _ in range(cnt):
                if v == 1:
                    seg, mt = struct.unpack(">Qq", b[q:q + 16]); q += 16
                else:
                    seg, mt = struct.unpack(">Ii", b[q:q + 8]); q += 8
                rate = struct.unpack(">i", b[q:q + 4])[0]; q += 4
                edits.append((seg, mt, rate))
    real = [e for e in edits if e[1] != -1]
    empty = [e for e in edits if e[1] == -1]
    if len(real) > 1:
        raise Refused("more than one edit")
    if any(e[2] != 1 << 16 for e in real):
        raise Refused("edit rate not 1")
    if empty and (edits[0][1] != -1 or len(empty) > 1):
        raise Refused("empty edit not leading")
    if real:
        shift -= real[0][1]
    if empty:
        num = empty[0][0] * timescale
        if num % movie_ts:
            raise Refused("empty edit not exact in track timescale")
        shift += num // movie_ts
    pts = [d + o + shift for d, o in zip(dts, off)]
    return {"timescale": timescale, "pts": pts, "dur": dur, "codec": codec, "samples": len(pts),
            "end_dts": end_dts, "edits": len(edits)}


def sorted_seconds(info):
    ts = info["timescale"]
    return [p / ts for p in sorted(info["pts"])]
