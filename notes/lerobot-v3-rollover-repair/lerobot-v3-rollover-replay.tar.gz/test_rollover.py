import copy
import unittest

from plan_rollover import Refused, build_plan


def fixture():
    rows = []
    for ep, (file, position, offset) in enumerate(((0, 0, 0), (1, 0, 0), (1, 10, 1))):
        rows.append({"ep": ep, "file": [0, file], "pos": position, "len": 10,
                     "from": position / 10 + offset, "to": position / 10 + 1 + offset,
                     "real_from": position / 10, "real_to": position / 10 + 1})
    records = [
        {"check": "info", "version": "v3.0", "video_keys": ["cam"], "fps": 10,
         "total_episodes": 3, "total_frames": 30},
        {"check": "episodes", "vk": "cam", "fps": 10, "rows": rows},
        {"check": "ds_done"},
    ]
    for i, frames in enumerate((10, 20)):
        records.append({"check": "file", "vk": "cam", "file": [0, i], "container": frames,
                        "meta": frames, "first_pts": 0, "end": frames / 10})
    return [{"ds": "fixture", **row} for row in records], rows


class RolloverTests(unittest.TestCase):
    def test_repairs_only_corrupt_suffix_and_is_idempotent(self):
        records, rows = fixture()
        self.assertEqual(build_plan(records, "fixture")["edits"], [
            {"camera": "cam", "file": [0, 1], "episode_index": 2, "first_frame": 10,
             "length": 10, "old_from": 2.0, "old_to": 3.0, "new_from": 1.0, "new_to": 2.0},
        ])
        rows[2].update({"from": 1.0, "to": 2.0})
        self.assertEqual(build_plan(records, "fixture")["edits"], [])

    def test_refuses_conflicting_evidence(self):
        records, _ = fixture()
        controls = {
            "drift": lambda r: r[1]["rows"][2].update({"from": 1.001, "to": 2.001}),
            "end mismatch": lambda r: r[1]["rows"][2].update({"to": 3.01}),
            "first episode off": lambda r: r[1]["rows"][1].update({"from": 1, "to": 2}),
            "wrong position": lambda r: r[1]["rows"][2].update(pos=9),
            "wrong frame count": lambda r: r[4].update(container=19),
            "short audit": lambda r: r[1]["rows"].pop(),
            "missing camera": lambda r: r[0]["video_keys"].append("other"),
            "duplicate file": lambda r: r.append(r[4]),
        }
        for name, change in controls.items():
            with self.subTest(name=name), self.assertRaises(Refused):
                amended = copy.deepcopy(records)
                change(amended)
                build_plan(amended, "fixture")


if __name__ == "__main__":
    unittest.main()
