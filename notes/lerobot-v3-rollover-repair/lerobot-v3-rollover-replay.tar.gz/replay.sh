#!/usr/bin/env bash
set -euo pipefail

: "${EXPECTED_MANIFEST_SHA256:?Use the extracted archive manifest digest}"
: "${ORIGINAL_SNAPSHOT:?Set the path to the clean, pinned source snapshot}"
: "${TMPDIR:?Set a writable directory on the snapshot filesystem}"
[[ $EXPECTED_MANIFEST_SHA256 =~ ^[0-9a-f]{64}$ ]]

source_path=$(realpath -e -- "$ORIGINAL_SNAPSHOT")
scratch_parent=$(realpath -e -- "$TMPDIR")
if [[ "$scratch_parent/" == "$source_path/"* ]] ||
    [[ $(stat -c %d -- "$source_path") != $(stat -c %d -- "$scratch_parent") ]]; then
  printf '%s\n' 'TMPDIR must be outside the snapshot and on the same filesystem.' >&2
  exit 2
fi

cd -- "$(dirname -- "$0")"
printf '%s  %s\n' "$EXPECTED_MANIFEST_SHA256" SHA256SUMS | sha256sum --strict --check
sha256sum --strict --check SHA256SUMS

scratch=$(mktemp -d "$scratch_parent/rollover.XXXXXXXX")
printf 'Replay output: %s\n' "$scratch"
export HF_HOME="$scratch/hf" HF_DATASETS_CACHE="$scratch/datasets"
export HF_LEROBOT_HOME="$scratch/lerobot"
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 HF_HUB_DISABLE_TELEMETRY=1

python -B -m unittest -v test_rollover test_apply_rollover
python -B apply_rollover.py "$source_path" source.json timing-audit.jsonl.gz \
  "$scratch/replacement.parquet" > "$scratch/apply.json"
awk '$2 == "replacement.parquet" || $2 == "apply.json"' EXPECTED-OUTPUTS.sha256 |
  (cd -- "$scratch" && sha256sum --strict --check)
for backend in pyav torchcodec; do
  python -B verify_rollover.py "$source_path" source.json \
    "$scratch/replacement.parquet" "$scratch/apply.json" "$scratch/patched-$backend" \
    "$scratch/$backend.jsonl" "$backend"
  awk -v report="$backend.jsonl" '$2 == report' EXPECTED-OUTPUTS.sha256 |
    (cd -- "$scratch" && sha256sum --strict --check)
done
printf '%s\n' 'Replay matched the replacement, apply receipt, and both decoder reports.'
