from pathlib import Path
import tempfile
import unittest

import pyarrow as pa
import pyarrow.parquet as pq

from apply_rollover import _write_replacement, sha256
from plan_rollover import Refused
from test_rollover import fixture


class ApplyTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.source = Path(directory.name) / "source"
        self.source.mkdir()
        self.output = Path(directory.name) / "replacement.parquet"
        self.path = "meta/episodes/chunk-000/file-000.parquet"
        self.original = self.source / self.path
        self.original.parent.mkdir(parents=True)
        self.records, rows = fixture()
        self.table = pa.table({
            "episode_index": [0, 1, 2],
            "length": [10, 10, 10],
            "videos/cam/chunk_index": [0, 0, 0],
            "videos/cam/file_index": [0, 1, 1],
            "videos/cam/from_timestamp": [row["from"] for row in rows],
            "videos/cam/to_timestamp": [row["to"] for row in rows],
            "other": ["keep", "each", "value"],
        }).replace_schema_metadata({b"test": b"keep"})
        pq.write_table(self.table, self.original)
        self.manifest = {"dataset": "fixture", "revision": "fixture-revision", "files": {
            self.path: {"size": self.original.stat().st_size, "sha256": sha256(self.original)},
        }}

    def test_changes_both_endpoints_in_replacement_only_and_refuses_overwrite(self):
        _write_replacement(self.source, self.manifest, self.records, self.output)
        repaired = pq.ParquetFile(self.output).read()
        self.assertEqual(repaired["videos/cam/from_timestamp"].to_pylist(), [0, 0, 1])
        self.assertEqual(repaired["videos/cam/to_timestamp"].to_pylist(), [1, 1, 2])
        untouched = ["episode_index", "length", "videos/cam/chunk_index", "videos/cam/file_index", "other"]
        self.assertTrue(repaired.select(untouched).equals(self.table.select(untouched), check_metadata=True))
        self.assertEqual(sha256(self.original), self.manifest["files"][self.path]["sha256"])
        replacement_hash = sha256(self.output)
        with self.assertRaises(FileExistsError):
            _write_replacement(self.source, self.manifest, self.records, self.output)
        self.assertEqual(sha256(self.output), replacement_hash)

    def test_refuses_changed_snapshot_without_creating_output(self):
        self.original.write_bytes(self.original.read_bytes() + b"changed")
        with self.assertRaisesRegex(Refused, "snapshot bytes differ"):
            _write_replacement(self.source, self.manifest, self.records, self.output)
        self.assertFalse(self.output.exists())

    def test_refuses_old_values_that_disagree_with_the_audit(self):
        self.records[1]["rows"][2]["from"] += 0.00001
        with self.assertRaisesRegex(Refused, "different videos/cam/from_timestamp"):
            _write_replacement(self.source, self.manifest, self.records, self.output)
        self.assertFalse(self.output.exists())

    def test_requires_receipt_revision_before_publishing(self):
        del self.manifest["revision"]
        with self.assertRaisesRegex(KeyError, "revision"):
            _write_replacement(self.source, self.manifest, self.records, self.output)
        self.assertFalse(self.output.exists())
        self.output.write_bytes(b"existing")
        with self.assertRaisesRegex(KeyError, "revision"):
            _write_replacement(self.source, self.manifest, self.records, self.output)
        self.assertEqual(self.output.read_bytes(), b"existing")
