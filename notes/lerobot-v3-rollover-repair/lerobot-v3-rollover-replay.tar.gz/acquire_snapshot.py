"""Download the pinned public source to a new directory of verified regular files."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from urllib.parse import quote


SOURCE_SHA256 = "0330621746d410c42f36e62087f8c8abe062c85da9df6f5150fbc8f1df584abd"


def acquire(destination):
    source = Path(__file__).with_name("source.json").read_bytes()
    if hashlib.sha256(source).hexdigest() != SOURCE_SHA256:
        raise ValueError("source.json differs from the pinned inventory")
    manifest = json.loads(source)
    base = f"https://huggingface.co/datasets/{manifest['dataset']}/resolve/{manifest['revision']}"

    destination.mkdir()
    try:
        for name, expected in manifest["files"].items():
            path = destination / name
            path.parent.mkdir(parents=True, exist_ok=True)
            print(f"Fetching {name}", flush=True)
            subprocess.run([
                "curl", "-q", "--fail", "--silent", "--show-error", "--location",
                "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "5",
                "--connect-timeout", "20", "--max-time", "300", "--retry", "2",
                "--max-filesize", str(expected["size"]), "--output", str(path),
                f"{base}/{quote(name)}",
            ], check=True)
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest()
            if path.stat().st_size != expected["size"] or digest != expected["sha256"]:
                raise ValueError(f"downloaded bytes differ for {name}")
    except (Exception, KeyboardInterrupt):
        shutil.rmtree(destination)
        raise
    print(f"Verified {len(manifest['files'])} source files in {destination}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path, help="new directory with an existing parent")
    args = parser.parse_args()
    try:
        acquire(args.destination)
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        parser.exit(2, f"Acquisition failed: {exc}\n")


if __name__ == "__main__":
    main()
